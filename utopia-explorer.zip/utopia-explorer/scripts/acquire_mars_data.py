"""Reproduce NASA Mars Trek imagery and PDS MOLA crop; no invented observations."""
from pathlib import Path
from datetime import datetime, timezone
from urllib.request import Request, urlopen
from concurrent.futures import ThreadPoolExecutor
import argparse, hashlib, json, math, xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
import io

HERE = Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,default=HERE/'assets',help='Asset output directory')
ASSETS = parser.parse_args().output.resolve()
ASSETS.mkdir(parents=True, exist_ok=True)
UA={'User-Agent':'UtopiaExplorer-educational-data-validation/1.0'}
NS={'w':'http://www.opengis.net/wmts/1.0','o':'http://www.opengis.net/ows/1.1'}
def fetch(url, extra=None):
    with urlopen(Request(url,headers={**UA,**(extra or {})}),timeout=45) as response:
        return response.status, dict(response.headers), response.read()
def save_json(name,obj):
    (ASSETS/name).write_text(json.dumps(obj,indent=2)+'\n')
def sha(data):return hashlib.sha256(data).hexdigest()

# NASA Trek advertises geographic top-left (-180,90) and 2^(z+1) x 2^z tile matrices.
layer='Mars_Viking_MDIM21_ClrMosaic_global_232m'
root=f'https://trek.nasa.gov/tiles/Mars/EQ/{layer}/1.0.0/'
cap=root+'WMTSCapabilities.xml'
status,headers,cap_data=fetch(cap)
(ASSETS/'viking_wmts.xml').write_bytes(cap_data)
cap_root=ET.fromstring(cap_data)
matrices=cap_root.findall('.//w:TileMatrixSet/w:TileMatrix',NS)
z=max(int(m.find('o:Identifier',NS).text) for m in matrices)
m=next(m for m in matrices if int(m.find('o:Identifier',NS).text)==z)
width=int(float(m.find('w:MatrixWidth',NS).text));height=int(float(m.find('w:MatrixHeight',NS).text))
tile_size=int(m.find('w:TileWidth',NS).text)
tile_degrees=360/width; dpp=tile_degrees/tile_size
requested={'west':109.,'east':111.,'south':44.,'north':46.}
# Keep original tile-grid pixels; no artificial upsampling.
x0=math.floor((requested['west']+180)/dpp);x1=math.ceil((requested['east']+180)/dpp)
y0=math.floor((90-requested['north'])/dpp);y1=math.ceil((90-requested['south'])/dpp)
tiles=[]
for row in range(y0//tile_size,(y1-1)//tile_size+1):
 for col in range(x0//tile_size,(x1-1)//tile_size+1):
  url=f'{root}default/default028mm/{z}/{row}/{col}.jpg'
  tiles.append((row,col,url))
def tile_fetch(item):
 row,col,url=item;status,headers,data=fetch(url)
 img=Image.open(io.BytesIO(data));img.load()
 if status!=200 or img.size!=(tile_size,tile_size):raise RuntimeError(f'Invalid tile {url}: {status} {img.size}')
 return row,col,url,data,img.convert('RGB')
rows=[r for r,_,_ in tiles];cols=[c for _,c,_ in tiles]
minrow,mincol=min(rows),min(cols)
mosaic=Image.new('RGB',((max(cols)-mincol+1)*tile_size,(max(rows)-minrow+1)*tile_size))
tile_info=[]
for row,col,url,data,img in ThreadPoolExecutor(max_workers=4).map(tile_fetch,tiles):
 mosaic.paste(img,((col-mincol)*tile_size,(row-minrow)*tile_size))
 tile_info.append({'row':row,'col':col,'url':url,'sha256':sha(data),'bytes':len(data)})
crop=mosaic.crop((x0-mincol*tile_size,y0-minrow*tile_size,x1-mincol*tile_size,y1-minrow*tile_size))
crop.save(ASSETS/'viking_mdim21.png')
image_metadata={
 'title':'Viking MDIM 2.1 color mosaic via NASA Mars Trek',
 'source':'NASA Viking / USGS Astrogeology; NASA/JPL-Caltech Mars Trek tile service',
 'capabilities_url':cap,'capabilities_sha256':sha(cap_data),
 'coordinate_convention':'Planetocentric latitude, positive-east longitude, degrees; Trek geographic/equirectangular grid',
 'projection':'Equirectangular / simple cylindrical, geographic degree axes; WMTS SupportedCRS urn:ogc:def:crs:EPSG::104905 as advertised by Trek. Do not interpret as Earth WGS84.',
 'supported_crs_as_advertised':'urn:ogc:def:crs:EPSG::104905',
 'bounds':{'west':x0*dpp-180,'east':x1*dpp-180,'north':90-y0*dpp,'south':90-y1*dpp},
 'bounds_semantics':'Outer pixel edges. Row zero is north. Pixel centers are west+(column+0.5)*degrees_per_pixel and north-(row+0.5)*degrees_per_pixel.',
 'image_size_px':list(crop.size),'degrees_per_pixel':dpp,
 'source_layer_nominal_resolution_m':232,
 'cached_wmts_level':z,
 'cached_angular_grid_m_at_equator':math.radians(dpp)*3396200,
 'note':'232 m is source-layer name nominal resolution; actual cached tile level7 samples 0.0054931640625 degrees/pixel (~326 m north-south on Mars). Broad regional context, insufficient to resolve EVA-scale obstacles. Colorized composite is not natural-color ground truth.',
 'tiles':tile_info,'retrieved_utc_date':datetime.now(timezone.utc).date().isoformat(),
 'asset_sha256':sha((ASSETS/'viking_mdim21.png').read_bytes())
}
save_json('imagery.json',image_metadata)
print('Imagery',crop.size,image_metadata['bounds'],flush=True)

# Read contiguous full rows of 128ppd raw topography using validated HTTP range.
pdsroot='https://pds-geosciences.wustl.edu/mgs/urn-nasa-pds-mgs_mola_topography_derived/meg128/'
product='megt88n090hb'
for ext in ['lbl','xml']:
 status,headers,data=fetch(pdsroot+product+'.'+ext)
 (ASSETS/(product+'.'+ext)).write_bytes(data)
rows_total=5632;cols_total=11520;ppd=128
requested_dem={'west':109.,'east':111.,'south':44.1,'north':45.9}
# PDS bounds denote raster outer edges, with first center88-0.5/128,90+0.5/128.
r0=math.floor((88-requested_dem['north'])*ppd)
r1=math.ceil((88-requested_dem['south'])*ppd)
c0=math.floor((requested_dem['west']-90)*ppd)
c1=math.ceil((requested_dem['east']-90)*ppd)
byte_start=r0*cols_total*2;byte_end=r1*cols_total*2-1
status,headers,chunk=fetch(pdsroot+product+'.img',{'Range':f'bytes={byte_start}-{byte_end}'})
expected=(r1-r0)*cols_total*2
if status!=206 or len(chunk)!=expected:
 raise RuntimeError(f'HTTP range not honored: {status},len{len(chunk)},expected{expected}')
content_range=next((v for k,v in headers.items() if k.lower()=='content-range'),None)
if content_range!=f'bytes {byte_start}-{byte_end}/{rows_total*cols_total*2}':
 raise RuntimeError(f'Unexpected Content-Range {content_range}')
raw=np.frombuffer(chunk,dtype='>i2').reshape((r1-r0,cols_total))
elevation=raw[:,c0:c1].astype(np.int16)
latitudes=88-(np.arange(r0,r1)+0.5)/ppd
longitudes=90+(np.arange(c0,c1)+0.5)/ppd
np.savez_compressed(ASSETS/'mola.npz',latitudes=latitudes,longitudes=longitudes,elevation_m=elevation)
meta={
 'title':'MGS MOLA MEGDR 128 pixels/degree topography crop',
 'source':'NASA Mars Global Surveyor MOLA Science Team, David E. Smith, Goddard Space Flight Center; archived by NASA PDS Geosciences Node, Washington University in St. Louis.',
 'product_id':'MEGT88N090HB.IMG','dataset_id':'MGS-M-MOLA-5-MEGDR-L3-V1.0',
 'pds4_identifier':'urn:nasa:pds:mgs_mola_topography_derived:data_meg128:megt88n090hb',
 'pds4_version':'1.1','product_version_pds3':'2.0',
 'source_url':pdsroot+product+'.img','pds3_label_url':pdsroot+product+'.lbl','pds4_label_url':pdsroot+product+'.xml',
 'source_coverage':{'west':90.,'east':180.,'north':88.,'south':44.},
 'source_shape':[rows_total,cols_total],'source_dtype':'MSB signed16-bit integer (>i2)',
 'units':'meters','vertical_reference':'Topography = planetary radius minus areoid radius; GMM3 (mgm1025), degree/order50, per source PDS3 description.',
 'coordinate_convention':'IAU2000 body-fixed planetocentric latitude, positive-east longitude, degrees',
 'projection':'Simple cylindrical/equirectangular; sphere radius3396.0 km, central meridian180°, latitude0°, standard parallel0°.',
 'source_angular_resolution_degrees':1/ppd,'source_map_scale_km_per_pixel':0.4630576672,
 'resolution_note':'0.463km is north-south and equatorial spacing. East-west ground spacing decreases with cos(latitude): about327m at45N. Bins without observations contain interpolated values. Up to12km source profile gaps are documented; grid spacing is not independent measurement resolution.',
 'bounds':{'west':90+c0/ppd,'east':90+c1/ppd,'north':88-r0/ppd,'south':88-r1/ppd},
 'bounds_semantics':'Outer pixel edges. Arrays contain pixel-center coordinates. Latitude decreases north to south; longitude increases west to east; elevation_m[row,col].',
 'crop_indices_zero_based_half_open':{'row_start':r0,'row_stop':r1,'col_start':c0,'col_stop':c1},
 'shape':list(elevation.shape),'valid_cells':int(elevation.size),'min_elevation_m':int(elevation.min()),'max_elevation_m':int(elevation.max()),
 'missing_data':'No missing-value sentinel is declared in the source label. Source interpolation fills unsampled bins; valid values do not guarantee observed shots in each cell.',
 'read_method':'HTTP206 contiguous full-width rows followed by column crop; no interpolation or value changes.',
 'http_content_range':content_range,'source_range_sha256':sha(chunk),'source_range_bytes':len(chunk),
 'source_full_file_bytes':rows_total*cols_total*2,'source_full_file_sha256':None,
 'source_full_hash_note':'Full129761280-byte IMG not downloaded. SHA256 above verifies the exact downloaded byte range; no claim is made to full-file hashing.',
 'asset_sha256':sha((ASSETS/'mola.npz').read_bytes()),
 'observation_start_utc':'1997-09-15T19:10:00Z','observation_end_utc':'2001-06-30T11:10:40Z','product_creation_utc':'2003-03-21T01:00:00Z',
 'retrieved_utc_date':datetime.now(timezone.utc).date().isoformat(),
 'slope_guidance':'Derive a regional grid-gradient slope using Mars radius and cos(latitude), report degrees. Do not treat as measured local EVA terrain slope or a certified safe path.'
}
save_json('mola.json',meta)
print('MOLA',elevation.shape,meta['bounds'],int(elevation.min()),int(elevation.max()),flush=True)
print('Assets saved:',ASSETS,flush=True)

"""Exercise the actual Streamlit app through observable mission-planning actions."""

from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest


ROOT = Path(__file__).resolve().parents[1]


def _no_exceptions(app):
    assert not app.exception, [str(error) for error in app.exception]


def _metric_values(app):
    return {metric.label: metric.value for metric in app.metric}


@pytest.fixture
def app():
    instance = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    _no_exceptions(instance)
    return instance


def test_default_eva01_shows_return_distance_and_complete_budget(app):
    values = _metric_values(app)
    assert values["Round-trip surface distance"] == "3.45 km"
    assert values["Travel estimate · return included"] == "1.44 h"
    assert values["EVA budget · including reserve"] == "2.60 h"
    assert values["Time remaining in budget"] == "+3.40 h"
    assert any("WITHIN DURATION BUDGET" in item.value for item in app.success)
    assert any("CONCEPTUAL ROUTE" in item.value for item in app.warning)


def test_reducing_maximum_duration_shows_overrun_without_changing_distance(app):
    app.slider(key="max_hours").set_value(1.0)
    app.run()
    _no_exceptions(app)
    assert any("EXCEEDS DURATION LIMIT" in item.value for item in app.error)
    values = _metric_values(app)
    assert values["Round-trip surface distance"] == "3.45 km"
    assert values["Time remaining in budget"] == "-1.60 h"


def test_multiple_destinations_preserve_selection_order_and_retrace_every_leg(app):
    app.multiselect(key="destinations").set_value(["S03", "S01"])
    app.run()
    _no_exceptions(app)
    legs = next(table.value for table in app.dataframe
                if {"Phase", "From", "To"}.issubset(table.value.columns))
    assert list(legs["Phase"]) == ["Outbound", "Outbound", "Return", "Return"]
    assert list(legs["From"]) == ["Utopia Base", "Geology comparison", "Ice-context survey", "Geology comparison"]
    assert list(legs["To"]) == ["Geology comparison", "Ice-context survey", "Geology comparison", "Utopia Base"]
    values = _metric_values(app)
    assert float(values["Round-trip surface distance"].split()[0]) > 3.45
    assert float(values["EVA budget · including reserve"].split()[0]) > 2.60


def test_clearing_destinations_removes_mission_and_its_budget(app):
    app.multiselect(key="destinations").set_value([])
    app.run()
    _no_exceptions(app)
    assert any("No EVA is currently planned" in item.value for item in app.info)
    values = _metric_values(app)
    assert values["Round-trip surface distance"] == "0.00 km"
    assert values["Travel estimate · return included"] == "0.00 h"
    assert values["EVA budget · including reserve"] == "0.00 h"
    assert values["Time remaining in budget"] == "+6.00 h"
    assert not app.error


def test_load_eva01_restores_destination_and_scenario_inputs(app):
    app.multiselect(key="destinations").set_value(["S04", "S02"])
    for key, value in {"speed": 1.0, "max_hours": 1.0, "science": 60,
                       "reserve": 120, "factor": 2.0}.items():
        app.slider(key=key).set_value(value)
    app.run()
    _no_exceptions(app)
    assert app.error
    app.button[0].click().run()
    _no_exceptions(app)
    assert app.multiselect(key="destinations").value == ["S01"]
    for key, value in {"speed": 3.0, "max_hours": 6.0, "science": 25,
                       "reserve": 45, "factor": 1.25}.items():
        assert app.slider(key=key).value == value
    assert _metric_values(app)["EVA budget · including reserve"] == "2.60 h"
    assert not app.error


def test_all_observation_layers_and_regional_extent_render_without_errors(app):
    layers = app.selectbox[0].options
    assert set(layers) == {"THEMIS daytime IR", "Viking color mosaic", "MOLA elevation",
                           "Regional slope", "USGS geology"}
    for layer in layers:
        app.selectbox[0].select(layer)
        app.selectbox[1].select("EVA area")
        app.run()
        _no_exceptions(app)
        assert app.get("plotly_chart"), f"No interactive chart for {layer}"
        app.selectbox[1].select("Regional context").run()
        _no_exceptions(app)
        assert app.selectbox[0].value == layer
        assert app.selectbox[1].value == "Regional context"


def test_source_panel_reports_bundled_observations_and_files_exist(app):
    sources = next(table.value for table in app.dataframe
                   if {"Source", "Status"}.issubset(table.value.columns))
    for source in ["Mars Odyssey THEMIS", "Viking MDIM 2.1", "NASA MGS MOLA MEGDR", "USGS SIM 3292"]:
        assert sources.loc[sources["Source"] == source, "Status"].iloc[0] == "Bundled"
    for filename in ["themis_dayir.png", "viking_mdim21.png", "mola.npz",
                     "geology_local.png", "geology_region.png"]:
        assert (ROOT / "data" / filename).stat().st_size > 0

"""A Mars-coordinate map: no terrestrial basemap or Earth distance engine."""
import math
import numpy as np
import plotly.graph_objects as go
from .core import MARS_MEAN_RADIUS_KM, great_circle_points, haversine_km

ORANGE = "#ff9a56"
CYAN = "#80d6df"
PAPER = "#10171f"


def expanded_route_points(waypoints):
    result = []
    for start, end in zip(waypoints, waypoints[1:]):
        segment = great_circle_points((start.lat, start.lon), (end.lat, end.lon), samples=40)
        result.extend(segment if not result else segment[1:])
    return result


def build_map(bundle, base, waypoints, plan, layer="Orbital imagery", scope="EVA area"):
    fig = go.Figure()
    if ((layer == "Viking color mosaic" and bundle.imagery is not None)
            or (layer == "THEMIS daytime IR" and bundle.themis is not None)):
        image = bundle.themis if layer == "THEMIS daytime IR" else bundle.imagery
        meta = bundle.themis_metadata if layer == "THEMIS daytime IR" else bundle.imagery_metadata
        b = meta["bounds"]
        fig.add_layout_image(source=image, xref="x", yref="y", x=b["west"], y=b["north"],
                             sizex=b["east"] - b["west"], sizey=b["north"] - b["south"],
                             sizing="stretch", xanchor="left", yanchor="top", layer="below", opacity=0.92)
    elif bundle.terrain is not None and layer in ["MOLA elevation", "Regional slope"]:
        terrain = bundle.terrain
        is_slope = layer == "Regional slope"
        values = terrain.slope_degrees() if is_slope else terrain.elevation_m
        fig.add_trace(go.Heatmap(x=terrain.longitudes, y=terrain.latitudes, z=values,
            colorscale=[[0, "#263c50"], [0.45, "#817060"], [0.75, "#cb9265"], [1, "#f3d5a4"]],
            colorbar=dict(title="Slope °" if is_slope else "m / areoid", thickness=10, len=0.65),
            hovertemplate="%{y:.4f}°N · %{x:.4f}°E<br>" + ("Regional slope %{z:.2f}°" if is_slope else "MOLA %{z:.0f} m") + "<extra></extra>"))
    elif layer == "USGS geology" and bundle.geology:
        image = bundle.geology.get("_region_image" if scope == "Regional context" else "_image")
        bounds = bundle.geology.get("region_bounds" if scope == "Regional context" else "local_bounds")
        if image is not None and bounds:
            fig.add_layout_image(source=image, xref="x", yref="y", x=bounds["west"], y=bounds["north"],
                sizex=bounds["east"]-bounds["west"], sizey=bounds["north"]-bounds["south"],
                sizing="stretch", xanchor="left", yanchor="top", layer="below", opacity=0.92)

    outbound = expanded_route_points(plan.outbound_points)
    returning = expanded_route_points(plan.return_points)
    for points, name, color, dash, width in [
        (outbound, "Outbound · conceptual", ORANGE, "solid", 5),
        (returning, "Return · same path", CYAN, "dash", 2)]:
        if points:
            fig.add_trace(go.Scatter(x=[p[1] for p in points], y=[p[0] for p in points], mode="lines",
                name=name, line=dict(color=color, width=width, dash=dash), hoverinfo="skip"))

    selected = {p.id for p in plan.outbound_points[1:]}
    if waypoints:
        fig.add_trace(go.Scatter(x=[p.lon for p in waypoints], y=[p.lat for p in waypoints],
            text=[p.id for p in waypoints], mode="markers+text", textposition="top center",
            customdata=[[p.name, p.purpose] for p in waypoints],
            hovertemplate="<b>%{customdata[0]}</b><br>Hypothetical science stop<br>%{y:.4f}°N · %{x:.4f}°E<br>%{customdata[1]}<extra></extra>",
            marker=dict(size=[13 if p.id in selected else 10 for p in waypoints],
                color=[ORANGE if p.id in selected else "#c0cbd7" for p in waypoints],
                line=dict(color="#111923", width=2)), name="Hypothetical destinations"))
    fig.add_trace(go.Scatter(x=[base.lon], y=[base.lat], mode="markers+text", text=["UTOPIA BASE"],
        textposition="bottom center", marker=dict(symbol="diamond", size=17, color=CYAN,
        line=dict(color="#10171f", width=2)), name="Hypothetical habitat",
        hovertemplate="<b>Utopia Base · hypothetical</b><br>%{y:.4f}°N · %{x:.4f}°E<br>Illustrative origin, not a selected landing site<extra></extra>"))

    if scope == "Regional context" and layer == "USGS geology":
        x_range, y_range = [90, 130], [35, 55]
        bar_km = 200
    elif scope == "Regional context":
        x_range, y_range = [109.02, 110.98], [44.12, 45.88]
        bar_km = 10
    else:
        x_range, y_range = [109.84, 110.16], [44.895, 45.105]
        bar_km = 2
    # A latitude-adjusted aspect ratio and scale bar are sufficient over this small study area.
    bar_lon = math.degrees(bar_km / (MARS_MEAN_RADIUS_KM * math.cos(math.radians(base.lat))))
    left = x_range[0] + (x_range[1]-x_range[0]) * .05
    bottom = y_range[0] + (y_range[1]-y_range[0]) * .07
    fig.add_shape(type="line", x0=left, x1=left+bar_lon, y0=bottom, y1=bottom,
                  line=dict(color="#ffffff", width=3))
    fig.add_annotation(x=left+bar_lon/2, y=bottom, yshift=14, text=f"{bar_km} km · Mars", showarrow=False,
                       font=dict(color="#ffffff", size=11), bgcolor="rgba(16,23,31,0.7)")
    fig.add_annotation(x=.97, y=.95, xref="paper", yref="paper", text="N ↑", showarrow=False,
                       font=dict(color="#ffffff", size=15), bgcolor="rgba(16,23,31,0.7)")
    fig.update_layout(height=560, paper_bgcolor=PAPER, plot_bgcolor=PAPER,
        font=dict(color="#c8d4e0", family="sans-serif", size=12),
        margin=dict(l=12, r=16, t=12, b=16), dragmode="pan", hovermode="closest",
        legend=dict(orientation="h", yanchor="top", y=-.14, x=0, font=dict(size=11)),
        xaxis=dict(title="East longitude · Mars", range=x_range, showgrid=True, gridcolor="rgba(200,213,224,.12)",
                   zeroline=False, ticksuffix="°E", tickformat=".2f", constrain="domain"),
        yaxis=dict(title="Planetocentric latitude", range=y_range, showgrid=True, gridcolor="rgba(200,213,224,.12)",
                   zeroline=False, ticksuffix="°N", tickformat=".2f", scaleanchor="x",
                   scaleratio=1/math.cos(math.radians(base.lat)), constrain="domain"),
        uirevision=f"{scope}:{layer}")
    return fig


def profile_chart(bundle, plan):
    points = expanded_route_points(plan.outbound_points)
    if bundle.terrain is None or not points:
        return None
    distances = [0.0]
    for start, end in zip(points, points[1:]):
        distances.append(distances[-1] + haversine_km(*start, *end))
    elevation = [bundle.terrain.sample(*point) for point in points]
    fig = go.Figure(go.Scatter(x=distances, y=elevation, mode="lines", connectgaps=False,
        line=dict(color=ORANGE, width=2),
        hovertemplate="%{x:.2f} km from base<br>%{y:.0f} m / areoid<extra></extra>"))
    fig.update_layout(height=210, margin=dict(l=0, r=10, t=10, b=0), paper_bgcolor=PAPER, plot_bgcolor=PAPER,
        font=dict(color="#c8d4e0"), xaxis=dict(title="Outbound distance · km", gridcolor="#25303d"),
        yaxis=dict(title="MOLA estimate · m", gridcolor="#25303d", rangemode="normal"))
    return fig

"""Read verified local Mars assets; unavailable observations remain unavailable."""
from dataclasses import dataclass, field
from pathlib import Path
import hashlib
import json
import math
import zipfile

import numpy as np
from PIL import Image

from .core import MARS_MEAN_RADIUS_KM


@dataclass
class Terrain:
    latitudes: np.ndarray
    longitudes: np.ndarray
    elevation_m: np.ndarray
    metadata: dict

    def sample(self, latitude: float, longitude: float, values=None):
        """Bilinear grid estimate between cell centers; never extrapolate."""
        try:
            if (isinstance(latitude, (bool, str)) or isinstance(longitude, (bool, str))
                    or not math.isfinite(latitude) or not math.isfinite(longitude)):
                return None
        except (TypeError, ValueError):
            return None
        longitude = longitude % 360
        if not (self.latitudes[-1] <= latitude <= self.latitudes[0]
                and self.longitudes[0] <= longitude <= self.longitudes[-1]):
            return None
        values = self.elevation_m if values is None else np.asarray(values)
        if values.shape != self.elevation_m.shape:
            raise ValueError("Sample grid shape does not match terrain")
        row = int(np.clip(np.searchsorted(-self.latitudes, -latitude) - 1,
                          0, len(self.latitudes) - 2))
        col = int(np.clip(np.searchsorted(self.longitudes, longitude) - 1,
                          0, len(self.longitudes) - 2))
        corners = values[row:row + 2, col:col + 2]
        if not np.isfinite(corners).all():
            return None
        fy = (self.latitudes[row] - latitude) / (self.latitudes[row] - self.latitudes[row + 1])
        fx = (longitude - self.longitudes[col]) / (self.longitudes[col + 1] - self.longitudes[col])
        return float((1 - fy) * ((1 - fx) * corners[0, 0] + fx * corners[0, 1])
                     + fy * ((1 - fx) * corners[1, 0] + fx * corners[1, 1]))

    def slope_degrees(self):
        """Regional gradient of the gridded topography, not local walking slope."""
        radius_m = MARS_MEAN_RADIUS_KM * 1000
        y = np.radians(self.latitudes) * radius_m
        x = np.radians(self.longitudes) * radius_m
        dy, dx_equatorial = np.gradient(self.elevation_m, y, x)
        dx = dx_equatorial / np.cos(np.radians(self.latitudes))[:, None]
        return np.degrees(np.arctan(np.hypot(dx, dy)))


@dataclass
class DataBundle:
    imagery: Image.Image | None = None
    imagery_metadata: dict = field(default_factory=dict)
    themis: Image.Image | None = None
    themis_metadata: dict = field(default_factory=dict)
    terrain: Terrain | None = None
    geology: dict | None = None
    errors: list[str] = field(default_factory=list)


def _metadata(directory, filename):
    value = json.loads((directory / filename).read_text())
    if not isinstance(value, dict):
        raise ValueError("Metadata must be a JSON object")
    return value


def _verify_hash(path, metadata):
    expected = metadata.get("asset_sha256")
    if expected and hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError(f"Integrity check failed for {path.name}")


def load_bundle(directory: Path) -> DataBundle:
    directory = Path(directory)
    bundle = DataBundle()
    try:
        meta = _metadata(directory, "imagery.json")
        path = directory / "viking_mdim21.png"
        _verify_hash(path, meta)
        bounds = meta["bounds"]
        if (not all(isinstance(bounds[k], (int, float)) and math.isfinite(bounds[k])
                    for k in ("west", "east", "south", "north"))
                or not (0 <= bounds["west"] < bounds["east"] <= 360
                        and -90 <= bounds["south"] < bounds["north"] <= 90)):
            raise ValueError("Invalid imagery bounds")
        with Image.open(path) as original:
            image = original.convert("RGB")
        if list(image.size) != meta["image_size_px"]:
            raise ValueError("Imagery dimensions disagree with metadata")
        bundle.imagery, bundle.imagery_metadata = image, meta
    except (OSError, ValueError, KeyError, TypeError) as exc:
        bundle.errors.append(f"Orbital imagery unavailable: {exc}")
    try:
        meta = _metadata(directory, "mola.json")
        path = directory / "mola.npz"
        _verify_hash(path, meta)
        with np.load(path, allow_pickle=False) as data:
            lat = np.array(data["latitudes"], dtype=float)
            lon = np.array(data["longitudes"], dtype=float)
            z = np.array(data["elevation_m"], dtype=float)
        if lat.ndim != 1 or lon.ndim != 1 or min(len(lat), len(lon)) < 2:
            raise ValueError("Terrain needs two 1D coordinate arrays of length >=2")
        if z.shape != (len(lat), len(lon)):
            raise ValueError("Terrain shape does not match coordinates")
        if not (np.isfinite(lat).all() and np.isfinite(lon).all()
                and (np.diff(lat) < 0).all() and (np.diff(lon) > 0).all()
                and np.abs(lat).max() <= 90 and lon.min() >= 0 and lon.max() < 360):
            raise ValueError("Terrain coordinate grid is invalid")
        if not np.isfinite(z).any():
            raise ValueError("Terrain has no valid elevations")
        if meta.get("units") != "meters":
            raise ValueError("Terrain units must be meters")
        bundle.terrain = Terrain(lat, lon, z, meta)
    except (OSError, ValueError, KeyError, TypeError, EOFError, zipfile.BadZipFile) as exc:
        bundle.errors.append(f"MOLA terrain unavailable: {exc}")
    if (directory / "themis.json").exists():
        try:
            meta = _metadata(directory, "themis.json")
            path = directory / "themis_dayir.png"
            _verify_hash(path, meta)
            with Image.open(path) as original:
                bundle.themis = original.convert("RGB")
            bundle.themis_metadata = meta
        except (OSError, ValueError, KeyError, TypeError) as exc:
            bundle.errors.append(f"THEMIS imagery unavailable: {exc}")
    try:
        meta = _metadata(directory, "geology.json")
        hashes = dict(meta.get("imagery_sha256", {}))
        for entry in meta.get("imagery", {}).values():
            hashes[entry["file"]] = entry["sha256"]
        for filename, expected in hashes.items():
            if filename not in {"geology_local.png", "geology_region.png"}:
                raise ValueError("Unexpected geological raster filename")
            _verify_hash(directory / filename, {"asset_sha256": expected})
        bundle.geology = meta
    except (OSError, ValueError, KeyError, TypeError) as exc:
        bundle.errors.append(f"Geological context unavailable: {exc}")
    return bundle


def sample_profile(terrain, points):
    if terrain is None:
        return [None for _ in points]
    return [terrain.sample(lat, lon) for lat, lon in points]

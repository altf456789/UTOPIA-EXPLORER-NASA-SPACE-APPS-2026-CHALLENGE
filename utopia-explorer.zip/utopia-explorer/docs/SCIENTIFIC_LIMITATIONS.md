# Scientific assumptions and limitations

Utopia Explorer is an educational mission-planning prototype for **Kazakh Space Nomads**. It supports the design of a hypothetical EVA; it does not certify a landing site or authorize an astronaut traverse.

## What is observed, derived, and proposed

| Information | Evidence status | What it supports |
| --- | --- | --- |
| THEMIS daytime infrared and Viking MDIM2.1 imagery | NASA mission imagery, served through NASA Mars Trek and cached locally | Regional surface context; not current conditions or calibrated local temperature |
| MOLA MEG128 elevation | NASA/PDS gridded laser-altimeter topography | Coarse elevation context and derived regional gradient |
| USGS SIM 3292 geology | Published global geological map by Tanaka et al. (2014), served through NASA Mars Trek | Regional map-unit context, not local material composition or ice confirmation |
| SHARAD regional figure PIA21138 | Published NASA interpretation of radar observations | Regional buried-ice motivation, not confirmation at a demo waypoint |
| Habitat and sampling waypoints | Hypothetical scenario coordinates | A repeatable demonstration, not discovered features or proposed NASA landing sites |
| Route, distance, time, budget warning | Calculations from scenario inputs | A conceptual estimate, not validated operational safety |

The three independent local evidence categories are **orbital imagery, topography and geological mapping**. The five map choices are **THEMIS daytime IR** (default), **Viking color mosaic**, **MOLA elevation**, **Regional slope**, and **USGS geology**. The two imagery choices share one category; slope is derived from MOLA and is not an independent observation.

A scenario center at **45° N, 110° E** places the demonstration in mid-northern Utopia Planitia. It was selected for regional relevance and accessible mapping coverage. It is not taken from a landing-site survey or confirmed ice footprint. Nearby waypoint coordinates are illustrative sampling stops. Their displayed precision permits calculation; it does not imply comparable scientific certainty.

## Coordinates, elevation, and scale

- Working coordinates are **planetocentric latitude**, degrees north, with **east-positive longitude**. Longitude conversion must change the coordinate convention explicitly rather than treating east and west as interchangeable labels.
- Route distances use a sphere with the NASA volumetric mean Mars radius **3,389.5 km**. Haversine distances are shortest surface arcs. They exclude obstacles, actual path length, suit gait, and elevation-induced distance. Ellipsoidal and local terrain corrections are outside this MVP.
- The default THEMIS daytime infrared mosaic has **100 m nominal source resolution**. Its cached grid samples approximately **81 m north–south**; oversampling does not produce 81 m effective resolution. Image brightness is neither calibrated local temperature nor a live environmental observation. The Viking mosaic is a historical colorized composite.
- MOLA MEG128 has nominal **128 pixels per degree** sampling: approximately **463 m north–south**, and **327 m east–west at 45° N**. Grid spacing is not a guarantee of independent feature resolution or local measurement accuracy.
- MOLA values are **metres relative to the Mars areoid**, not Earth sea level, spacecraft altitude, or distance to the planet's center. Raster indexing, missing pixels and out-of-bounds samples must be handled before displaying a value.
- Any gradient derived from this grid describes coarse terrain. It can miss steep local crater rims, boulders, pits, soft material and obstacles. It must not become a walkability or safety certificate. A smooth appearance on a regional map does not establish a safe path.
- The cached imagery and topography are historical observations. Enlarging a map adds no source detail. Source identifiers, projection, coverage, resolution and acquisition records are listed in [Data sources](../DATA_SOURCES.md) and the data metadata.

## Route and time model

A mission visits the selected destinations in order and returns to the habitat by **retracing the outbound legs**. Outbound and return geometries therefore overlap on the map. Both journeys are included in total distance and travel time.

The time estimate uses the configured walking speed and planning allowance, plus science-stop time. The budget comparison reserves the configured contingency time as well. Speed, allowance, science duration, maximum EVA duration and reserve are **user assumptions**, not validated Mars astronaut performance values.

The demonstration defaults use **3 km/h**, a **1.25 planning allowance**, a **6-hour maximum EVA**, **25 minutes per science stop**, and a **45-minute reserve**. Compare the actual computed result with these constraints; do not substitute an assumed route distance. “Within configured time budget” describes this arithmetic only. Exceeding the budget is a warning, while remaining below it is not evidence that the EVA is safe.

The planner does not model suit oxygen, carbon dioxide removal, thermal limits, exertion, fatigue, emergency rescue, daylight, communications, return contingencies beyond the entered reserve, or changing environmental conditions. Operational approval would require these inputs and validated terrain-aware routing.

## Ice, geology, and environment

NASA/JPL's 2016 SHARAD summary describes an ice-rich deposit in the **39–49° N** portion of Utopia Planitia. The latitude band alone is not a footprint. Neither that regional result nor a nearby image proves ice at a selected waypoint. PIA21138 is presented with its original legend as a **regional reference image**, not as a georeferenced local ice overlay. The app makes no local ice-depth, abundance, purity or extractability prediction.

The NASA Trek query at **45° N, 110° E** returns **eAb — Early Amazonian basin unit**, from **Tanaka et al. (2014), USGS SIM 3292, 1:20,000,000**. The cached local map extent is uniformly within that mapped unit. Its uniform fill is genuine coarse mapping, not evidence of uniform local rocks, outcrops or subsurface properties. A separate regional view covers **90–130° E, 35–55° N** to show geological context.

A scientific stop may investigate surface textures, the regional map interpretation or possible ice-related hypotheses. Such objectives are questions to test, not geologic observations invented for a marker. Sampling a global map at a hypothetical marker reports a published map classification; it is not a field measurement there. The basin-unit label does not establish water ice or material composition.

General panels describe Mars's thin atmosphere, cold conditions, dust and radiation exposure. They are **not local weather observations or forecasts**. No live temperature, wind, dust opacity, radiation or site-specific hazard measurements are provided. Unavailable measurements must remain unavailable; they must not be replaced with fabricated defaults.

## Challenge and earlier research

The supplied 2026 Space Apps challenge URL returned **HTTP 503** during development on **2026-11-15**. Its title and task framing follow the user's brief; the official listing and competition rules were not independently confirmed in that fetch.

The uploaded *The Mars Project* presentation is earlier **group research by Team Tokamak Bruno**, identified in the PDF as an 11-member research team. It supplies project motivation. Its future habitat, energy, agriculture and water-system assumptions are not validated measurements, and they are not used as scientific map layers. The current team is **Kazakh Space Nomads**. This project does not claim sole authorship of the earlier work or infer identical membership.

## References

- THEMIS source capabilities: https://trek.nasa.gov/tiles/Mars/EQ/THEMIS_DayIR_ControlledMosaics_100m_v2_oct2018/1.0.0/WMTSCapabilities.xml
- Viking source capabilities: https://trek.nasa.gov/tiles/Mars/EQ/Mars_Viking_MDIM21_ClrMosaic_global_232m/1.0.0/WMTSCapabilities.xml
- NASA/PDS MOLA product label: https://pds-geosciences.wustl.edu/mgs/urn-nasa-pds-mgs_mola_topography_derived/meg128/megt88n090hb.xml
- USGS Geologic Map of Mars (Tanaka et al., 2014): https://pubs.usgs.gov/sim/3292/
- NASA Trek geology service: https://trek.nasa.gov/mars/trekarcgis/rest/services/SIM3292_Global_Geology/MapServer/0
- NASA Mars Fact Sheet: https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html
- NASA/JPL SHARAD report: https://www.jpl.nasa.gov/news/mars-ice-deposit-holds-as-much-water-as-lake-superior/
- NASA Photojournal PIA21138: https://science.nasa.gov/photojournal/location-of-large-subsurface-water-ice-deposit-in-utopia-planitia-mars/
- NASA Mars Facts: https://science.nasa.gov/mars/facts/
- Dataset-level provenance and access limitations: [Data sources](../DATA_SOURCES.md).

"""Mars coordinates, spherical surface distances, and conceptual EVA budgets.

Distances are great-circle lower bounds on a sphere with Mars's mean radius.
They do not represent walkable, surveyed, or hazard-cleared paths. The separate
terrain factor increases the estimated travel time; it never fabricates a safe
route. Times use ordinary 60-minute Earth hours, not Martian sols.

Radius and reference-ellipsoid axes: NASA Mars Fact Sheet (mean radius 3389.5
km; equatorial radius 3396.19 km; polar radius 3376.20 km),
https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html .
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable, Sequence


MARS_MEAN_RADIUS_KM = 3389.5
MARS_EQUATORIAL_RADIUS_KM = 3396.19
MARS_POLAR_RADIUS_KM = 3376.20


def _finite(value: float, name: str) -> float:
    """Accept a finite numeric value, rejecting missing data and booleans."""
    if isinstance(value, (bool, str, bytes)) or value is None:
        raise ValueError(f"{name} must be a finite number.")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f"{name} must be a finite number.") from error
    if not math.isfinite(result):
        raise ValueError(f"{name} must be a finite number.")
    return result


def _latitude(value: float) -> float:
    result = _finite(value, "Latitude")
    if not -90.0 <= result <= 90.0:
        raise ValueError("Latitude must be between -90 and 90 degrees.")
    return result


def normalize_longitude(lon: float, convention: str = "180") -> float:
    """Normalize positive-east longitude to [-180,180) or [0,360).

    This wraps longitudes only. It does not convert west-positive to east-
    positive longitude; negate west-positive values before calling.
    """
    value = _finite(lon, "Longitude")
    if convention == "180":
        return (value + 180.0) % 360.0 - 180.0
    if convention == "360":
        return value % 360.0
    raise ValueError("Longitude convention must be '180' or '360'.")


def planetographic_to_planetocentric(lat_deg: float) -> float:
    """Convert Mars oblate-ellipsoid planetographic to planetocentric latitude."""
    latitude = math.radians(_latitude(lat_deg))
    return math.degrees(math.atan2(
        MARS_POLAR_RADIUS_KM**2 * math.sin(latitude),
        MARS_EQUATORIAL_RADIUS_KM**2 * math.cos(latitude),
    ))


def planetocentric_to_planetographic(lat_deg: float) -> float:
    """Convert Mars oblate-ellipsoid planetocentric to planetographic latitude."""
    latitude = math.radians(_latitude(lat_deg))
    return math.degrees(math.atan2(
        MARS_EQUATORIAL_RADIUS_KM**2 * math.sin(latitude),
        MARS_POLAR_RADIUS_KM**2 * math.cos(latitude),
    ))


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Shortest spherical Mars surface distance in km, using centric latitude."""
    phi1 = math.radians(_latitude(lat1))
    phi2 = math.radians(_latitude(lat2))
    longitude1 = normalize_longitude(lon1)
    longitude2 = normalize_longitude(lon2)
    d_phi = phi2 - phi1
    d_lambda = math.radians(normalize_longitude(longitude2 - longitude1))
    hav = math.sin(d_phi / 2.0)**2 + (
        math.cos(phi1) * math.cos(phi2) * math.sin(d_lambda / 2.0)**2
    )
    hav = min(1.0, max(0.0, hav))
    return 2.0 * MARS_MEAN_RADIUS_KM * math.atan2(
        math.sqrt(hav), math.sqrt(1.0 - hav)
    )


def _coordinates(point: Sequence[float]) -> tuple[float, float]:
    try:
        if len(point) != 2:
            raise ValueError("A coordinate must contain (latitude, longitude).")
        return _latitude(point[0]), normalize_longitude(point[1])
    except (TypeError, IndexError) as error:
        raise ValueError("A coordinate must contain (latitude, longitude).") from error


def great_circle_points(
    start: Sequence[float], end: Sequence[float], samples: int = 48,
) -> list[tuple[float, float]]:
    """Sample a conceptual great-circle segment, including both endpoints.

    Returned pairs are (planetocentric latitude, east longitude in [-180,180)).
    Exactly antipodal endpoints have infinitely many shortest paths; a stable
    arbitrary great circle is used for plotting, never for navigation.
    """
    if isinstance(samples, bool) or not isinstance(samples, int) or samples < 2:
        raise ValueError("samples must be an integer of at least 2.")
    point1, point2 = _coordinates(start), _coordinates(end)

    def vector(point: tuple[float, float]) -> tuple[float, float, float]:
        lat, lon = map(math.radians, point)
        return math.cos(lat) * math.cos(lon), math.cos(lat) * math.sin(lon), math.sin(lat)

    first, last = vector(point1), vector(point2)
    dot = min(1.0, max(-1.0, sum(a * b for a, b in zip(first, last))))
    normal = tuple(b - dot * a for a, b in zip(first, last))
    norm = math.sqrt(sum(component**2 for component in normal))
    if norm < 1e-12 and dot > 0:
        return [point1] * (samples - 1) + [point2]
    if norm < 1e-12:
        # Pick the Cartesian axis least aligned with the start vector.
        index = min(range(3), key=lambda i: abs(first[i]))
        axis = tuple(1.0 if i == index else 0.0 for i in range(3))
        dot_axis = first[index]
        normal = tuple(axis[i] - dot_axis * first[i] for i in range(3))
        norm = math.sqrt(sum(component**2 for component in normal))
    basis = tuple(component / norm for component in normal)
    angle = math.acos(dot)
    result = []
    for sample in range(samples):
        theta = angle * sample / (samples - 1)
        x, y, z = (
            math.cos(theta) * first[i] + math.sin(theta) * basis[i]
            for i in range(3)
        )
        result.append((math.degrees(math.atan2(z, math.hypot(x, y))),
                       normalize_longitude(math.degrees(math.atan2(y, x)))))
    result[0], result[-1] = point1, point2
    return result


@dataclass(frozen=True)
class Waypoint:
    """A mission marker, with planetocentric latitude and positive-east longitude."""

    id: str
    name: str
    lat: float
    lon: float
    purpose: str
    kind: str = "hypothetical"

    def __post_init__(self) -> None:
        object.__setattr__(self, "lat", _latitude(self.lat))
        object.__setattr__(self, "lon", normalize_longitude(self.lon, "360"))
        if not self.id or not self.name:
            raise ValueError("Waypoint id and name must not be empty.")


@dataclass(frozen=True)
class MissionConstraints:
    """User-chosen scenario settings, not measured spacesuit performance."""

    speed_kmh: float = 3.0
    max_duration_hours: float = 6.0
    science_minutes_per_stop: float = 25.0
    reserve_minutes: float = 45.0
    terrain_factor: float = 1.25

    def __post_init__(self) -> None:
        for name in self.__dataclass_fields__:
            value = _finite(getattr(self, name), name)
            object.__setattr__(self, name, value)
        if self.speed_kmh <= 0:
            raise ValueError("Walking speed must be greater than zero.")
        if self.max_duration_hours <= 0:
            raise ValueError("Maximum EVA duration must be greater than zero.")
        if self.science_minutes_per_stop < 0 or self.reserve_minutes < 0:
            raise ValueError("Science and reserve minutes must not be negative.")
        if self.terrain_factor < 1:
            raise ValueError("Terrain factor must be at least 1.")


@dataclass(frozen=True)
class MissionPlan:
    outbound_points: list[Waypoint]
    return_points: list[Waypoint]
    outbound_km: float
    return_km: float
    total_km: float
    travel_hours: float
    science_hours: float
    reserve_hours: float
    total_hours: float
    margin_hours: float
    status: str
    legs: list[dict]
    constraints: MissionConstraints


def plan_mission(
    base: Waypoint,
    destinations: Iterable[Waypoint],
    constraints: MissionConstraints,
) -> MissionPlan:
    """Budget an ordered outbound traverse and an exact retrace to base.

    total_km is the spherical minimum distance. Travel time multiplies it by
    the user-selected terrain factor and divides by speed. The required EVA
    budget includes travel, science stops and a fixed contingency reserve.
    An empty destination list represents no mission, so all durations are zero.
    """
    if not isinstance(base, Waypoint) or not isinstance(constraints, MissionConstraints):
        raise ValueError("A valid base waypoint and mission constraints are required.")
    try:
        stops = list(destinations)
    except TypeError as error:
        raise ValueError("Destinations must be an iterable of waypoints.") from error
    if any(not isinstance(point, Waypoint) for point in stops):
        raise ValueError("Every destination must be a valid waypoint.")
    outbound = [base, *stops]
    returning = list(reversed(outbound))
    legs = []
    for phase, points in (("outbound", outbound), ("return", returning)):
        for first, last in zip(points, points[1:]):
            legs.append({
                "from": first.name,
                "to": last.name,
                "distance_km": haversine_km(first.lat, first.lon, last.lat, last.lon),
                "phase": phase,
            })
    outbound_km = sum(leg["distance_km"] for leg in legs if leg["phase"] == "outbound")
    return_km = sum(leg["distance_km"] for leg in legs if leg["phase"] == "return")
    total_km = outbound_km + return_km
    travel_hours = total_km * constraints.terrain_factor / constraints.speed_kmh
    science_hours = len(stops) * constraints.science_minutes_per_stop / 60.0
    reserve_hours = constraints.reserve_minutes / 60.0 if stops else 0.0
    total_hours = travel_hours + science_hours + reserve_hours
    margin = constraints.max_duration_hours - total_hours
    if not stops:
        status = "no_destinations"
    elif math.isclose(margin, 0.0, rel_tol=0.0, abs_tol=1e-9):
        status = "at_limit"
    elif margin < 0:
        status = "over_budget"
    else:
        status = "within_budget"
    return MissionPlan(outbound, returning, outbound_km, return_km, total_km,
                       travel_hours, science_hours, reserve_hours, total_hours,
                       margin, status, legs, constraints)

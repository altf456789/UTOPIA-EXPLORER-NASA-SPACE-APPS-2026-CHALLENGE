# Utopia Explorer — Mars EVA Mission Planner

**Team:** Kazakh Space Nomads  
**Challenge:** Interplanetary Survival Guide: Martian Map, as supplied in the project brief

Utopia Explorer helps a hypothetical astronaut plan a science EVA around a proposed settlement in Utopia Planitia. It brings three independent evidence categories—NASA orbital imagery, MOLA topography and USGS geological mapping—into an interactive Python/Streamlit map, then connects selected sampling stops with a clearly labelled conceptual outbound route and a return to base.

Five views expose THEMIS daytime infrared imagery, a Viking color mosaic, MOLA elevation, slope derived from MOLA, and the USGS global geological map. The geological context follows Tanaka et al. (2014), SIM 3292; the hypothetical base falls within the mapped Early Amazonian basin unit. These regional data do not establish local rock composition or ice.

The planner calculates surface distance using Mars's radius, estimates travel and science-stop time, and compares the mission with a configurable EVA duration and contingency reserve. Astronauts can change destinations, walking speed and planning assumptions to see how the mission budget changes. A warning identifies plans that exceed the entered time budget.

The EVA-01 demonstration explores regional geology and asks where future observations might test water-ice-related hypotheses. NASA's published SHARAD research provides regional context; the application does not label an arbitrary waypoint as a confirmed ice deposit. The habitat and sampling coordinates remain explicitly hypothetical.

The project addresses a practical problem: useful planetary information is spread across scientific sources, while a field explorer needs a readable map, a scientific purpose and a route back to shelter. Utopia Explorer combines these in a transparent planning workflow and keeps measured data, derived calculations and proposed mission choices distinct.

The prototype includes source attribution, documented scientific limits, a reproducible application and calculation tests. Its imagery is historical; THEMIS brightness is not calibrated local temperature. It does not provide terrain-validated safe routing or live local hazard measurements. Earlier settlement research is credited to the original Team Tokamak Bruno group; the current application is a Kazakh Space Nomads project with disclosed AI assistance.

**Verification note:** The provided official 2026 challenge URL returned HTTP 503 during development. Confirm the listing, eligibility and submission requirements before submitting.

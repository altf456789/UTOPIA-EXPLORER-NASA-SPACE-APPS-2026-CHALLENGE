"""Utopia Explorer: transparent Mars mission-planning calculations."""


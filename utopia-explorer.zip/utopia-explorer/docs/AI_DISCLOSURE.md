# AI assistance disclosure

**Project:** Utopia Explorer — Mars EVA Mission Planner  
**Team:** Kazakh Space Nomads

OpenAI's Codex assisted with software design and implementation, dataset discovery and retrieval checks, coordinate and mission-planning calculations, test preparation, documentation and demonstration materials. Parallel AI agents helped review source evidence and the earlier research context.

NASA and USGS remain the sources of the planetary observations. AI-generated code, explanations and hypothetical scenario coordinates are not NASA observations, NASA recommendations or evidence of NASA endorsement. Local measurements were not invented to fill missing data.

The uploaded *The Mars Project* presentation was used as background. Its identified authoring group is **Team Tokamak Bruno**, an 11-member research team. The current project does not claim that the user individually created all of that earlier work. Its engineering assumptions were not treated as validated scientific data.

The team should review the application, references, executed validation results and competition-specific disclosure requirements before submission. This statement records assistance used in creating this prototype; it does not claim that the official 2026 rules were verified or that NASA has approved the project.

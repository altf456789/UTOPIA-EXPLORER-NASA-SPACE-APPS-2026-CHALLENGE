"""Utopia Explorer — a source-backed, explicitly hypothetical Mars EVA planner."""
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
import json

import streamlit as st
from PIL import Image

from utopia.core import Waypoint, MissionConstraints, plan_mission
from utopia.data import load_bundle
from utopia.map_view import build_map, profile_chart

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
BASE = Waypoint("BASE", "Utopia Base", 45.0, 110.0,
    "Illustrative settlement origin; no landing feasibility or habitat safety established.")
WAYPOINTS = [
    Waypoint("S01", "Ice-context survey", 45.020, 110.030,
        "Document surface morphology and plan follow-up ground radar in a region motivated by published SHARAD research. Local ice is unconfirmed."),
    Waypoint("S02", "Topography station", 44.980, 110.065,
        "Compare regional MOLA elevation estimates with a proposed local survey; check how orbital resolution limits route assessment."),
    Waypoint("S03", "Geology comparison", 45.055, 109.950,
        "Propose observations to test the coarse USGS basin-unit interpretation. No outcrop or sampled material has been confirmed here."),
    Waypoint("S04", "Extended traverse", 44.925, 110.120,
        "Explore the time cost of a longer conceptual traverse before committing to field reconnaissance."),
]
LOOKUP = {p.id: p for p in WAYPOINTS}
DEFAULTS = dict(destinations=["S01"], speed=3.0, max_hours=6.0,
                science=25, reserve=45, factor=1.25)

st.set_page_config(page_title="Utopia Explorer · Mars EVA Planner", page_icon="🟠", layout="wide")
st.markdown("""<style>
.block-container{padding-top:3.5rem;padding-bottom:3rem;max-width:1600px}
[data-testid="stSidebar"]{border-right:1px solid #26313e}
.eyebrow{color:#a2b1c2;font-size:.73rem;letter-spacing:.16em;font-weight:600}
.brand{font-size:1.05rem;font-weight:750;letter-spacing:.14em;color:#f2f5f8}
.brand span{color:#ff9a56}
.hero{font-size:clamp(2rem,3vw,3.2rem);font-weight:750;letter-spacing:-.035em;line-height:1.13;margin:.5rem 0 .55rem}
.subtitle{color:#b5c2d0;max-width:880px;line-height:1.6;margin-bottom:1.3rem}
.chip{display:inline-block;font-size:.7rem;padding:.3rem .55rem;border:1px solid #364453;border-radius:4px;margin:0 .45rem .5rem 0;color:#c4d2de}
.chip.live{color:#8edce1;border-color:#3b6771}
.science-card{padding:.9rem 1rem;background:#141d28;border:1px solid #2a3746;border-radius:7px;margin-bottom:.7rem}
.science-card .label{color:#ffad78;font-size:.73rem;letter-spacing:.08em;font-weight:650}
.science-card h4{font-size:1rem;margin:.3rem 0;color:#f0f3f7}
.science-card p{font-size:.84rem;color:#c1ccd8;line-height:1.5;margin:.3rem 0}
.small-note{font-size:.78rem;color:#a9b8c8;line-height:1.55}
[data-testid="stMetric"]{background:#141d28;border:1px solid #293545;border-radius:8px;padding:.8rem 1rem}
[data-testid="stMetricLabel"]{font-size:.8rem;color:#b5c3d2}
[data-testid="stMetricValue"]{font-size:1.8rem}
h3{font-size:1.25rem!important;letter-spacing:-.015em}
button,p,label{line-height:1.5}
</style>""", unsafe_allow_html=True)


@st.cache_resource
def get_data():
    bundle = load_bundle(DATA)
    if bundle.geology:
        try:
            with Image.open(DATA / "geology_local.png") as image:
                bundle.geology["_image"] = image.convert("RGB")
            bundle.geology["_bounds"] = bundle.geology.get("local_bounds",
                dict(west=109.6, east=110.4, south=44.7, north=45.3))
            with Image.open(DATA / "geology_region.png") as image:
                bundle.geology["_region_image"] = image.convert("RGB")
        except OSError:
            bundle.errors.append("Geological map image unavailable; regional classification remains documented.")
    return bundle


def load_demo():
    for key, value in DEFAULTS.items():
        st.session_state[key] = value.copy() if isinstance(value, list) else value


for key, value in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = value

with st.sidebar:
    st.markdown('<div class="brand">UTOPIA<span> / </span>EXPLORER</div>', unsafe_allow_html=True)
    st.caption("KAZAKH SPACE NOMADS")
    st.divider()
    st.markdown("### EVA configuration")
    st.caption("Scenario inputs · ordinary 60-minute hours")
    st.button("Load EVA-01 example", on_click=load_demo, width="stretch")
    selected_ids = st.multiselect("Exploration destinations", list(LOOKUP),
        format_func=lambda key: f"{key} · {LOOKUP[key].name}", key="destinations",
        help="Visit order follows your selection order. The return journey retraces every leg.")
    speed = st.slider("Walking speed · km/h", 0.5, 6.0, step=0.25, key="speed")
    max_hours = st.slider("Maximum EVA duration · h", 1.0, 12.0, step=0.25, key="max_hours")
    with st.expander("Science, reserve & route allowance", expanded=True):
        science = st.slider("Science time per stop · min", 0, 120, step=5, key="science")
        reserve = st.slider("Contingency reserve · min", 0, 180, step=5, key="reserve")
        factor = st.slider("Travel-time allowance ×", 1.0, 3.0, step=0.05, key="factor",
            help="A user-chosen multiplier for detours and slower progress; not calibrated from MOLA or spacesuit data.")
    st.caption("Settings are illustrative planning assumptions, not certified spacesuit or human-performance limits.")
    st.divider()
    st.markdown("**Hypothetical Utopia Base**")
    st.caption("45.000°N · 110.000°E\n\nRounded demonstration coordinates. No landing site has been selected or certified.")

bundle = get_data()
constraints = MissionConstraints(speed, max_hours, science, reserve, factor)
destinations = [LOOKUP[key] for key in selected_ids]
plan = plan_mission(BASE, destinations, constraints)

st.markdown('<div class="eyebrow">MARS SURFACE OPERATIONS / EVA-01 / PLANNING SIMULATION</div>', unsafe_allow_html=True)
st.markdown('<div class="hero">Every step needs a plan.</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">Plan a conceptual science traverse in Utopia Planitia. Compare orbital evidence, budget a return to base, and see where the data stops.</div>', unsafe_allow_html=True)
st.markdown('<span class="chip live">BUNDLED NASA / USGS DATA</span><span class="chip">UTOPIA PLANITIA · 45°N / 110°E</span><span class="chip">HYPOTHETICAL MISSION</span>', unsafe_allow_html=True)

metric_cols = st.columns(4)
for col, label, value, help_text in [
    (metric_cols[0], "Round-trip surface distance", f"{plan.total_km:.2f} km", "Spherical Mars minimum; route allowance changes time, not the displayed distance."),
    (metric_cols[1], "Travel estimate · return included", f"{plan.travel_hours:.2f} h", "Distance × allowance ÷ walking speed. Science and contingency are separate."),
    (metric_cols[2], "EVA budget · including reserve", f"{plan.total_hours:.2f} h", "Travel + science stops + contingency reserve."),
    (metric_cols[3], "Time remaining in budget", f"{plan.margin_hours:+.2f} h", "Maximum EVA duration minus the total required budget.")]:
    col.metric(label, value, help=help_text)

if plan.status == "over_budget":
    st.error(f"EXCEEDS DURATION LIMIT · {-plan.margin_hours:.2f} h over the {max_hours:.2f} h budget. Shorten the mission or revise its assumptions.")
elif plan.status == "at_limit":
    st.warning("AT DURATION LIMIT · No unallocated time remains beyond the configured contingency reserve.")
elif plan.status == "no_destinations":
    st.info("Select a destination to build an outbound and return mission. No EVA is currently planned.")
else:
    st.success(f"WITHIN DURATION BUDGET · {plan.margin_hours:.2f} h unallocated after the configured reserve. Terrain and life-support safety are unverified.")

tabs = st.tabs(["Mission map", "Science & terrain", "Sources & limitations"])
with tabs[0]:
    map_col, mission_col = st.columns([3.1, 1.25], gap="large")
    with map_col:
        st.markdown("### Utopia Planitia / exploration area")
        layers = []
        if bundle.themis is not None:
            layers.append("THEMIS daytime IR")
        if bundle.imagery is not None:
            layers.append("Viking color mosaic")
        if bundle.terrain is not None:
            layers.extend(["MOLA elevation", "Regional slope"])
        if bundle.geology and bundle.geology.get("_image") is not None:
            layers.append("USGS geology")
        if not layers:
            layers = ["Coordinate grid · data unavailable"]
            st.warning("Map observations are missing. This is a coordinate grid with hypothetical markers, not a Mars image.")
        controls = st.columns([1.5, 1])
        layer = controls[0].selectbox("Map layer", layers)
        scope = controls[1].selectbox("Map extent", ["EVA area", "Regional context"])
        fig = build_map(bundle, BASE, WAYPOINTS, plan, layer, scope)
        st.plotly_chart(fig, width="stretch", theme=None, config={"scrollZoom":True, "displaylogo":False}, key="mars_map")
        captions = {
            "THEMIS daytime IR": "NASA Mars Odyssey THEMIS / ASU / USGS, served by Mars Trek. Controlled daytime infrared mosaic, source nominal 100 m; cached sampling ≈81 m north–south. Brightness is not a calibrated or live temperature layer.",
            "Viking color mosaic": "NASA Viking / USGS MDIM 2.1, served by Mars Trek. Cached pixels ≈325 m north–south; colorized composite. Zoom adds no observational detail.",
            "MOLA elevation": "NASA MGS MOLA MEGDR · 128 pixels/degree. Topography in metres relative to the source areoid. Interpolated bins and coarse sampling cannot resolve EVA obstacles.",
            "Regional slope": "Derived from the MOLA grid gradient. Grid-scale slope in degrees, not measured local walking slope. No slope-based safety clearance.",
            "USGS geology": "USGS Tanaka et al. (2014), SIM 3292, 1:20,000,000. Uniform local fill is the real mapped Early Amazonian basin unit (eAb), not missing detail."}
        st.caption(captions.get(layer, "No raster observations available."))
        st.warning("CONCEPTUAL ROUTE · Great-circle segments and their exact return retrace. Paths have not been surveyed for rocks, slopes, dust, communication, radiation or suit limits.")
    with mission_col:
        st.markdown("### Mission brief")
        st.markdown("**EVA-01 · geological exploration**")
        st.caption("Assess a potential water-ice-related research site through reconnaissance planning. No local ice deposit is confirmed.")
        if destinations:
            for index, point in enumerate(destinations, 1):
                elevation = bundle.terrain.sample(point.lat, point.lon) if bundle.terrain else None
                elevation_label = f"{elevation:,.0f} m · MOLA grid estimate" if elevation is not None else "Elevation unavailable"
                st.markdown(f'<div class="science-card"><div class="label">STOP {index:02d} / {point.id} / HYPOTHETICAL</div><h4>{point.name}</h4><p>{point.lat:.3f}°N · {point.lon:.3f}°E<br>{elevation_label}</p><p>{point.purpose}</p></div>', unsafe_allow_html=True)
            st.markdown("**Visit sequence**")
            st.write("Base → " + " → ".join(point.id for point in destinations) + " → retrace → Base")
        else:
            st.caption("Choose one or more hypothetical science stops in EVA configuration.")
        st.markdown("**Time allocation**")
        st.table({"Component": ["Travel / out + return", "Science stops", "Contingency reserve", "Total required budget"],
                  "Hours": [f"{plan.travel_hours:.2f}", f"{plan.science_hours:.2f}", f"{plan.reserve_hours:.2f}", f"{plan.total_hours:.2f}"]})
        record = {
            "mission": "EVA-01", "team": "Kazakh Space Nomads", "generated_utc": datetime.now(timezone.utc).isoformat(),
            "coordinate_reference": "Mars planetocentric degrees, east-positive longitude [0,360)",
            "radius_km": 3389.5, "base": asdict(BASE), "destinations": [asdict(p) for p in destinations],
            "constraints": asdict(constraints), "plan": asdict(plan),
            "interpretation": "Hypothetical locations; conceptual minimum-distance route; within_budget is a duration check, not a safety clearance.",
    "data": {"imagery": bundle.imagery_metadata, "themis":bundle.themis_metadata, "mola": bundle.terrain.metadata if bundle.terrain else None,
                     "geology": {k:v for k,v in bundle.geology.items() if not k.startswith('_')} if bundle.geology else None},
            "missing_data": bundle.errors,
        }
        st.download_button("Download mission plan · JSON", json.dumps(record, indent=2, allow_nan=False),
            file_name="EVA-01_mission_plan.json", mime="application/json", width="stretch")
    with st.expander("Outbound & return leg calculations"):
        if plan.legs:
            st.dataframe([{"Phase":leg["phase"].title(), "From":leg["from"], "To":leg["to"], "Surface distance · km":round(leg["distance_km"], 3)} for leg in plan.legs], hide_index=True, width="stretch")
            st.caption(f"Outbound {plan.outbound_km:.3f} km + return {plan.return_km:.3f} km. Return retraces all selected stops in reverse order.")
        else:
            st.caption("No route legs. Select at least one destination.")

with tabs[1]:
    left, right = st.columns([1.6, 1], gap="large")
    with left:
        st.markdown("### Orbital evidence, at its actual scale")
        st.write("This prototype combines orbital imagery (THEMIS and Viking), MOLA topography and the USGS global geological map. Regional slope is derived from MOLA and is not an independent observation. THEMIS brightness is an infrared mosaic, not a live temperature measurement.")
        if bundle.terrain is not None:
            st.markdown("**Outbound elevation profile**")
            profile = profile_chart(bundle, plan)
            if profile is not None:
                st.plotly_chart(profile, width="stretch", theme=None, key="elevation_profile")
                st.caption("Bilinear samples of the coarse MOLA grid along the conceptual route. Fine plot sampling does not add elevation measurements. Return retraces the same profile.")
            else:
                st.info("Choose a destination to see the MOLA grid profile.")
            slopes = bundle.terrain.slope_degrees()
            samples = []
            for point in [BASE, *destinations]:
                z = bundle.terrain.sample(point.lat, point.lon)
                slope = bundle.terrain.sample(point.lat, point.lon, slopes)
                samples.append({"Hypothetical marker":point.name, "MOLA grid · m / areoid":"Unavailable" if z is None else f"{z:,.0f}",
                                "Regional grid slope · °":"Unavailable" if slope is None else f"{slope:.2f}"})
            st.dataframe(samples, hide_index=True, width="stretch")
        else:
            st.warning("MOLA missing: no elevations, profile or slopes are inferred.")
        st.markdown("**Geological context**")
        if bundle.geology:
            st.write("The checked local study area is mapped as **eAb · Early Amazonian basin unit** by USGS Tanaka et al. (2014). At 1:20 million scale this provides regional stratigraphic context; it does not identify rock type, outcrops or ice at a proposed stop.")
            if (DATA / "geology_region.png").exists():
                st.image(str(DATA / "geology_region.png"), caption="USGS SIM 3292 via NASA Mars Trek · regional context 90–130°E, 35–55°N. The local habitat concept is at 110°E, 45°N; map colors show different regional geological units.")
        else:
            st.info("Geological source unavailable. No local classification assigned.")
    with right:
        st.markdown("### Why investigate ice-related science?")
        st.write("NASA/JPL reported SHARAD radar evidence for a large buried ice-rich deposit in part of Utopia Planitia, between 39° and 49°N. That regional study motivates follow-up science; latitude alone does not place a waypoint inside the deposit.")
        if (DATA / "sharad_context.jpg").exists():
            st.image(str(DATA / "sharad_context.jpg"), caption="Published regional ice-assessment reference, PIA21138. Original legend retained. NASA/JPL-Caltech/Univ. of Rome/ASI/PSI. Not a georeferenced local ice layer.")
        st.link_button("Read NASA/JPL’s SHARAD report", "https://www.jpl.nasa.gov/news/mars-ice-deposit-holds-as-much-water-as-lake-superior/", width="stretch")
        st.markdown("**Environmental conditions**")
        st.write("Mars has a thin, CO₂-dominated atmosphere. Dust, thermal exposure and radiation matter to EVA planning, but this app has no site-specific weather, dust, radiation or life-support observations.")
        st.info("LOCAL CONDITIONS: UNAVAILABLE\n\nNo live temperature, pressure, radiation or dust values are displayed. The route allowance is a scenario input, not an environmental forecast.")
        st.link_button("NASA Mars facts", "https://science.nasa.gov/mars/facts/", width="stretch")

with tabs[2]:
    st.markdown("### Evidence and assumptions stay visible")
    st.write("**Observed / mapped:** bundled orbital imagery, the MOLA gridded product, and published USGS regional units. **Derived:** spherical distances, grid slope, elevation-profile interpolation and EVA time budget. **Hypothetical:** habitat, all waypoints, walking speed, science duration and reserve.")
    st.markdown("**Coordinate and calculation conventions**")
    st.write("All plotted coordinates are Mars body-fixed planetocentric latitude and positive-east longitude in degrees. The Cartesian map uses equirectangular degree axes with a local latitude-adjusted aspect ratio. It uses no Earth tiles or WGS84 distances. MOLA’s source projection uses a 3,396 km sphere; route distances use Mars’s mean radius of 3,389.5 km. Metres of MOLA height are relative to its source areoid, not Earth sea level.")
    st.code("Round-trip km = outbound great-circle legs + exact reverse legs\nTravel hours = round-trip km × travel-time allowance ÷ speed (km/h)\nRequired hours = travel + science per stop + contingency reserve\nBudget margin = configured maximum − required hours", language="text")
    st.caption("The allowance adjusts estimated time, not the plotted path or measured distance. Grid elevations are not integrated into a 3D walking distance. All times are ordinary 60-minute hours.")
    source_rows = [
        {"Source":"Mars Odyssey THEMIS", "Use":"Daytime infrared orbital context", "Resolution / scale":"Source 100 m; cached ≈81 m samples", "Status":"Bundled" if bundle.themis else "Unavailable"},
        {"Source":"Viking MDIM 2.1", "Use":"Orbital context", "Resolution / scale":"Cached ≈325 m north–south", "Status":"Bundled" if bundle.imagery else "Unavailable"},
        {"Source":"NASA MGS MOLA MEGDR", "Use":"Elevation; derived regional slope", "Resolution / scale":"128 px/degree ≈463 m north–south", "Status":"Bundled" if bundle.terrain else "Unavailable"},
        {"Source":"USGS SIM 3292", "Use":"Regional geological units", "Resolution / scale":"1:20,000,000", "Status":"Bundled" if bundle.geology else "Unavailable"},
        {"Source":"SHARAD / PIA21138", "Use":"Published regional ice context", "Resolution / scale":"Reference figure only", "Status":"Bundled reference" if (DATA/"sharad_context.jpg").exists() else "Unavailable"},
    ]
    st.dataframe(source_rows, hide_index=True, width="stretch")
    for label, url in [
        ("NASA Mars Trek imagery capabilities", "https://trek.nasa.gov/tiles/Mars/EQ/Mars_Viking_MDIM21_ClrMosaic_global_232m/1.0.0/WMTSCapabilities.xml"),
        ("NASA PDS MOLA product label", "https://pds-geosciences.wustl.edu/mgs/urn-nasa-pds-mgs_mola_topography_derived/meg128/megt88n090hb.xml"),
        ("USGS geological map publication", "https://pubs.usgs.gov/sim/3292/"),
        ("NASA Mars radius reference", "https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html")]:
        st.markdown(f"[{label}]({url})")
    st.markdown("**Unavailable capabilities**")
    st.write("There is no obstacle detection, verified safe routing, rover-scale terrain model, georeferenced ice-deposit footprint, live environmental feed, spacesuit consumables model, or independently verified landing site. A duration check does not establish mission safety.")
    st.markdown("**Research credit and AI assistance**")
    st.write("The supplied Mars Project presentation is earlier collaborative research credited to Team Tokamak Bruno. Utopia Explorer is a Kazakh Space Nomads hackathon prototype. AI assisted software development, source inspection, tests and documentation; the team must review and understand the submission. Earlier group work is not represented as any individual’s sole work.")
    st.caption("The supplied 2026 challenge URL returned HTTP 503 during verification. Challenge alignment follows the task brief and should be checked against the official page before submission.")
    for error in bundle.errors:
        st.warning(error)
    with st.expander("Inspect bundled data provenance"):
        st.json({"imagery":bundle.imagery_metadata, "themis":bundle.themis_metadata, "mola":bundle.terrain.metadata if bundle.terrain else None,
                 "geology":{k:v for k,v in bundle.geology.items() if not k.startswith('_')} if bundle.geology else None})

st.divider()
st.markdown('<div class="small-note">KAZAKH SPACE NOMADS · UTOPIA EXPLORER<br>Educational planning prototype · NASA and USGS data attribution does not imply endorsement. Cached data verified 15 November 2026.</div>', unsafe_allow_html=True)

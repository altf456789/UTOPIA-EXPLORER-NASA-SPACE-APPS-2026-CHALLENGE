# Suggested two-minute demonstration

## Before recording

1. Install the requirements and launch the app as described in [README](../README.md).
2. Open **EVA-01** with its initial single destination. Keep **THEMIS daytime IR**, the default genuine imagery view, visible.
3. Confirm the mission settings: walking speed **3 km/h**, planning allowance **1.25**, maximum duration **6 hours**, science time **25 minutes per stop**, reserve **45 minutes**.
4. Check the default S01 mission against these calculation references: **3.44915 km** round trip, **1.43715 h** travel, and **2.60381 h** required budget including science and reserve. The UI rounds these to **3.45 km**, **1.44 h** and **2.60 h**. These are scenario-model outputs, not measured walking performance.
5. Keep a second, more demanding combination of stops ready, or reduce the EVA limit until a warning appears. Leave enough time to show the return journey and scientific limits.

## Spoken script

**0:00–0:20 — The problem and map**

“An astronaut needs a scientific destination and enough time to return to shelter. We are Kazakh Space Nomads, and this is Utopia Explorer for a hypothetical settlement in Utopia Planitia. This is genuine NASA THEMIS daytime infrared imagery. Our base and sampling stops are hypothetical.”

**0:20–0:45 — A complete mission**

“EVA-01 visits our proposed ice-context survey stop. Its conceptual route returns along the same path to base. Both journeys total about 3.45 kilometres using Mars's radius. Travel takes about 1.44 hours with our chosen allowance. Science and reserve bring the required budget to 2.60 hours.”

**0:45–1:10 — A decision the user can change**

“We can change destinations, walking speed, science time, reserve and maximum duration. Tightening the time limit triggers this warning. Restoring the six-hour limit brings the scenario within its configured budget. That is a time calculation; terrain and suit safety still need verification.”

**1:10–1:35 — Scientific evidence**

“Switching to MOLA shows coarse topography; slope is derived from the same grid. USGS geology adds an independent regional map: this area is classified as Early Amazonian basin unit. In Science and Terrain, this published NASA SHARAD figure motivates ice-related research. It does not confirm ice beneath our stop.”

**1:35–2:00 — Why it is useful and what remains**

“We combine imagery, topography and geology with a science purpose and return budget. Sources and uncertainties remain visible. Infrared brightness is not live temperature, and this route is conceptual. Higher-resolution terrain, suit consumables and local environmental measurements are needed before real operational planning. Every scientific claim must remain traceable to its source.”

## Demonstration checks

- Point to the hypothetical-base label and the imagery attribution.
- Show the selected destination and both journey totals.
- Trigger the duration warning, then restore a feasible configured budget.
- Switch through **MOLA elevation** and **USGS geology**, then show the regional SHARAD reference under **Science & terrain**.
- Explain that slope is derived from MOLA and that the 1:20 million geological unit does not establish local rock composition or ice.
- Show the scientific evidence and its uncertainty text.
- Do not call a location a confirmed ice deposit or call a route safe.

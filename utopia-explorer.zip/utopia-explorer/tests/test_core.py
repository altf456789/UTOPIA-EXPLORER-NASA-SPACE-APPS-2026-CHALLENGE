"""Analytic and edge-case tests for scientific planning invariants."""

import math

import pytest

from utopia.core import (
    MARS_MEAN_RADIUS_KM,
    MissionConstraints,
    Waypoint,
    great_circle_points,
    haversine_km,
    normalize_longitude,
    planetocentric_to_planetographic,
    planetographic_to_planetocentric,
    plan_mission,
)


@pytest.mark.parametrize("value,expected180,expected360", [
    (0, 0, 0), (180, -180, 180), (-180, -180, 180),
    (360, 0, 0), (-10, -10, 350), (725, 5, 5), (-725, -5, 355),
])
def test_longitude_conventions(value, expected180, expected360):
    assert normalize_longitude(value) == expected180
    assert normalize_longitude(value, "360") == expected360


@pytest.mark.parametrize("latitude", [-90, -75, -45, 0, 45, 75, 90])
def test_latitude_conversion_roundtrip(latitude):
    centric = planetographic_to_planetocentric(latitude)
    assert planetocentric_to_planetographic(centric) == pytest.approx(latitude, abs=1e-10)
    if 0 < latitude < 90:
        assert centric < latitude
    if -90 < latitude < 0:
        assert centric > latitude


def test_latitude_conversion_known_formula():
    # Independent evaluation of tan(centric)=(b/a)^2*tan(graphic).
    expected = math.degrees(math.atan((3376.20 / 3396.19)**2))
    assert planetographic_to_planetocentric(45) == pytest.approx(expected)


def test_quarter_circumference_uses_mars_radius():
    distance = haversine_km(0, 0, 0, 90)
    assert distance == pytest.approx(math.pi * 3389.5 / 2)
    assert distance != pytest.approx(math.pi * 6371.0 / 2)


def test_identical_antipodal_and_antimeridian_distances():
    assert haversine_km(45, 110, 45, 110) == pytest.approx(0)
    assert haversine_km(0, 0, 0, 180) == pytest.approx(math.pi * MARS_MEAN_RADIUS_KM)
    expected = math.radians(2) * MARS_MEAN_RADIUS_KM
    assert haversine_km(0, 179, 0, -179) == pytest.approx(expected)
    assert haversine_km(0, 359, 0, 1) == pytest.approx(expected)


def test_distance_symmetry_and_poles():
    first = haversine_km(45.0, 110.0, 45.01, 110.02)
    assert first == pytest.approx(haversine_km(45.01, 110.02, 45.0, 110.0))
    assert haversine_km(90, 0, 90, 120) == pytest.approx(0, abs=1e-10)


@pytest.mark.parametrize("missing", [None, float("nan"), float("inf"), -float("inf"), True, "45"])
def test_missing_or_invalid_coordinates_are_rejected(missing):
    with pytest.raises(ValueError):
        haversine_km(missing, 110, 45, 110)
    with pytest.raises(ValueError):
        normalize_longitude(missing)
    with pytest.raises(ValueError):
        Waypoint("x", "Unknown", 45, missing, "Test")


@pytest.mark.parametrize("latitude", [-90.01, 90.01])
def test_latitude_range(latitude):
    with pytest.raises(ValueError, match="between"):
        planetographic_to_planetocentric(latitude)


def test_unknown_coordinate_convention_is_rejected():
    with pytest.raises(ValueError):
        normalize_longitude(110, "west")


def test_great_circle_sampling_equatorial_arc():
    points = great_circle_points((0, 0), (0, 90), samples=5)
    assert points[0] == (0, 0)
    assert points[-1] == (0, 90)
    assert points[2] == pytest.approx((0, 45))
    segment_lengths = [haversine_km(*first, *last) for first, last in zip(points, points[1:])]
    assert sum(segment_lengths) == pytest.approx(math.pi * MARS_MEAN_RADIUS_KM / 2)


def test_great_circle_antipodal_and_same_point_are_finite():
    points = great_circle_points((0, 0), (0, 180), samples=9)
    assert len(points) == 9
    assert all(math.isfinite(value) for point in points for value in point)
    assert sum(haversine_km(*first, *last) for first, last in zip(points, points[1:])) == pytest.approx(math.pi * MARS_MEAN_RADIUS_KM)
    assert great_circle_points((45, 110), (45, 110), 3) == [(45, 110)] * 3


@pytest.mark.parametrize("samples", [0, 1, True, 2.5])
def test_invalid_great_circle_samples(samples):
    with pytest.raises(ValueError):
        great_circle_points((0, 0), (0, 90), samples)


@pytest.fixture
def markers():
    return (
        Waypoint("base", "Hypothetical base", 45, 110, "Start"),
        Waypoint("a", "Proposed A", 45.01, 110.02, "Reconnaissance"),
        Waypoint("b", "Proposed B", 45.025, 110.01, "Sampling"),
    )


def test_return_route_retraces_selected_waypoints(markers):
    base, first, second = markers
    plan = plan_mission(base, [first, second], MissionConstraints())
    assert plan.outbound_points == [base, first, second]
    assert plan.return_points == [second, first, base]
    assert plan.return_km == pytest.approx(plan.outbound_km)
    assert plan.total_km == pytest.approx(2 * plan.outbound_km)
    assert [leg["phase"] for leg in plan.legs] == ["outbound", "outbound", "return", "return"]


def test_travel_science_and_reserve_all_count_toward_budget(markers):
    base, first, _ = markers
    settings = MissionConstraints(speed_kmh=2, terrain_factor=1.5,
                                  science_minutes_per_stop=30, reserve_minutes=45)
    plan = plan_mission(base, [first], settings)
    expected_one_way = haversine_km(base.lat, base.lon, first.lat, first.lon)
    assert plan.travel_hours == pytest.approx(2 * expected_one_way * 1.5 / 2)
    assert plan.science_hours == pytest.approx(0.5)
    assert plan.reserve_hours == pytest.approx(0.75)
    assert plan.total_hours == pytest.approx(plan.travel_hours + 1.25)
    assert plan.margin_hours == pytest.approx(6 - plan.total_hours)


def test_threshold_equality_and_overrun(markers):
    base, first, _ = markers
    duration = plan_mission(base, [first], MissionConstraints()).total_hours
    assert plan_mission(base, [first], MissionConstraints(max_duration_hours=duration)).status == "at_limit"
    assert plan_mission(base, [first], MissionConstraints(max_duration_hours=duration - 0.01)).status == "over_budget"
    assert plan_mission(base, [first], MissionConstraints(max_duration_hours=duration + 0.01)).status == "within_budget"


def test_faster_walking_reduces_only_travel_time(markers):
    base, first, _ = markers
    slow = plan_mission(base, [first], MissionConstraints(speed_kmh=2))
    fast = plan_mission(base, [first], MissionConstraints(speed_kmh=4))
    assert fast.travel_hours == pytest.approx(slow.travel_hours / 2)
    assert fast.science_hours == slow.science_hours
    assert fast.reserve_hours == slow.reserve_hours


def test_empty_selection_is_no_mission(markers):
    base, _, _ = markers
    plan = plan_mission(base, [], MissionConstraints())
    assert plan.status == "no_destinations"
    assert plan.total_km == 0
    assert plan.total_hours == 0
    assert plan.margin_hours == 6
    assert plan.legs == []


@pytest.mark.parametrize("settings", [
    {"speed_kmh": 0}, {"speed_kmh": -1}, {"max_duration_hours": 0},
    {"terrain_factor": 0.9}, {"reserve_minutes": -1},
    {"science_minutes_per_stop": -1}, {"speed_kmh": float("nan")},
    {"max_duration_hours": float("inf")}, {"reserve_minutes": None},
    {"speed_kmh": True},
])
def test_invalid_mission_settings(settings):
    with pytest.raises(ValueError):
        MissionConstraints(**settings)


def test_missing_waypoints_rejected(markers):
    with pytest.raises(ValueError):
        plan_mission(markers[0], [None], MissionConstraints())
    with pytest.raises(ValueError):
        plan_mission(None, [markers[1]], MissionConstraints())

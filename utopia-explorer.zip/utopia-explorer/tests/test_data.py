"""Verify georeferencing, physical gradient units, and missing-data behavior."""

import hashlib
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image
import pytest

from utopia.core import MARS_MEAN_RADIUS_KM
from utopia.data import Terrain, load_bundle, sample_profile


@pytest.fixture
def terrain():
    latitudes = np.array([46.0, 45.0, 44.0])
    longitudes = np.array([109.0, 110.0, 111.0])
    longitude_grid, latitude_grid = np.meshgrid(longitudes, latitudes)
    # A bilinear surface with a nonzero mixed term catches row/column swaps.
    elevations = 100 * latitude_grid + 10 * longitude_grid + latitude_grid * longitude_grid
    return Terrain(latitudes, longitudes, elevations, {"units": "meters"})


def test_bilinear_sample_uses_north_first_rows_and_eastward_columns(terrain):
    latitude, longitude = 45.25, 109.75
    expected = 100 * latitude + 10 * longitude + latitude * longitude
    assert terrain.sample(latitude, longitude) == pytest.approx(expected)
    assert terrain.sample(latitude, longitude - 360) == pytest.approx(expected)


@pytest.mark.parametrize("row,column", [(0, 0), (0, 2), (2, 0), (2, 2), (1, 1)])
def test_exact_cell_centers_and_grid_edges(terrain, row, column):
    assert terrain.sample(terrain.latitudes[row], terrain.longitudes[column]) == pytest.approx(
        terrain.elevation_m[row, column]
    )


@pytest.mark.parametrize("latitude,longitude", [
    (46.0001, 110), (43.9999, 110), (45, 108.9999), (45, 111.0001),
    (float("nan"), 110), (45, float("inf")),
])
def test_outside_and_nonfinite_samples_are_missing_not_extrapolated(terrain, latitude, longitude):
    assert terrain.sample(latitude, longitude) is None


@pytest.mark.parametrize("latitude,longitude", [(None, 110), (45, None)])
def test_absent_coordinate_samples_remain_missing(terrain, latitude, longitude):
    assert terrain.sample(latitude, longitude) is None


def test_missing_grid_cells_are_not_filled_with_invented_values(terrain):
    terrain.elevation_m[1, 1] = np.nan
    assert terrain.sample(45.5, 109.5) is None


def test_sample_grid_shape_is_checked(terrain):
    with pytest.raises(ValueError, match="shape"):
        terrain.sample(45, 110, np.zeros((2, 2)))


def test_missing_terrain_profiles_preserve_length_and_nulls():
    points = [(45, 110), (45.01, 110.01)]
    assert sample_profile(None, points) == [None, None]


def test_coarse_slope_of_known_plane_has_correct_mars_meter_units():
    latitudes = np.array([45.01, 45, 44.99])
    longitudes = np.array([109.99, 110, 110.01])
    radius_m = MARS_MEAN_RADIUS_KM * 1000
    y = np.radians(latitudes) * radius_m
    x = np.radians(longitudes) * radius_m
    longitude_grid, latitude_grid = np.meshgrid(x, y)
    north_gradient, east_gradient = 0.1, 0.2
    z = north_gradient * latitude_grid + east_gradient * math.cos(math.radians(45)) * longitude_grid
    actual = Terrain(latitudes, longitudes, z, {}).slope_degrees()
    expected_rows = np.degrees(np.arctan(np.hypot(
        north_gradient,
        east_gradient * math.cos(math.radians(45)) / np.cos(np.radians(latitudes)),
    )))
    assert actual.shape == z.shape
    assert actual == pytest.approx(np.broadcast_to(expected_rows[:, None], z.shape), abs=1e-8)


def test_constant_elevation_has_zero_regional_slope():
    flat = Terrain(np.array([45.01, 45, 44.99]), np.array([109.99, 110, 110.01]),
                   np.full((3, 3), -4000.0), {})
    assert flat.slope_degrees() == pytest.approx(np.zeros((3, 3)), abs=1e-10)


def _write_terrain(directory, *, lat=None, lon=None, z=None, units="meters", with_hash=True):
    lat = np.array([46, 45, 44]) if lat is None else np.array(lat)
    lon = np.array([109, 110, 111]) if lon is None else np.array(lon)
    z = np.arange(9).reshape(3, 3) if z is None else np.array(z)
    path = directory / "mola.npz"
    np.savez(path, latitudes=lat, longitudes=lon, elevation_m=z)
    metadata = {"units": units}
    if with_hash:
        metadata["asset_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    (directory / "mola.json").write_text(json.dumps(metadata))


def test_absent_source_files_leave_explicit_errors(tmp_path):
    bundle = load_bundle(tmp_path)
    assert bundle.imagery is None
    assert bundle.terrain is None
    assert bundle.errors
    assert any("imagery unavailable" in message for message in bundle.errors)
    assert any("MOLA terrain unavailable" in message for message in bundle.errors)


@pytest.mark.parametrize("changes", [
    {"lat": [44, 45, 46]},
    {"lon": [111, 110, 109]},
    {"lat": [46, 45, 45]},
    {"lon": [109, 110, 360]},
    {"lat": [91, 45, 44]},
    {"z": np.zeros((2, 3))},
    {"z": np.full((3, 3), np.nan)},
    {"units": "kilometers"},
])
def test_invalid_source_grid_or_units_are_rejected(tmp_path, changes):
    _write_terrain(tmp_path, **changes)
    bundle = load_bundle(tmp_path)
    assert bundle.terrain is None
    assert any("MOLA terrain unavailable" in message for message in bundle.errors)


def test_valid_source_grid_loads_without_fabricating_other_assets(tmp_path):
    _write_terrain(tmp_path)
    bundle = load_bundle(tmp_path)
    assert bundle.terrain is not None
    assert bundle.terrain.sample(45, 110) == 4
    assert bundle.imagery is None


def test_corrupted_terrain_fails_hash_integrity_check(tmp_path):
    _write_terrain(tmp_path)
    with (tmp_path / "mola.npz").open("ab") as destination:
        destination.write(b"corruption")
    bundle = load_bundle(tmp_path)
    assert bundle.terrain is None
    assert any("Integrity check failed" in message for message in bundle.errors)


def test_malformed_npz_is_reported_even_without_an_optional_hash(tmp_path):
    (tmp_path / "mola.json").write_text(json.dumps({"units": "meters"}))
    (tmp_path / "mola.npz").write_bytes(b"PK\x03\x04truncated archive")
    bundle = load_bundle(tmp_path)
    assert bundle.terrain is None
    assert any("MOLA terrain unavailable" in message for message in bundle.errors)


def test_mismatched_imagery_dimensions_are_rejected(tmp_path):
    Image.new("RGB", (4, 3)).save(tmp_path / "viking_mdim21.png")
    (tmp_path / "imagery.json").write_text(json.dumps({
        "bounds": {"west": 109, "east": 111, "south": 44, "north": 46},
        "image_size_px": [3, 4],
    }))
    bundle = load_bundle(tmp_path)
    assert bundle.imagery is None
    assert any("dimensions disagree" in message for message in bundle.errors)


def test_bundled_mola_grid_has_valid_coordinates_integrity_and_coverage():
    directory = Path(__file__).resolve().parents[1] / "data"
    if not (directory / "mola.npz").exists():
        pytest.skip("Bundled MOLA asset is not yet available")
    bundle = load_bundle(directory)
    assert bundle.terrain is not None, bundle.errors
    terrain = bundle.terrain
    assert terrain.elevation_m.shape == (len(terrain.latitudes), len(terrain.longitudes))
    assert (np.diff(terrain.latitudes) < 0).all()
    assert (np.diff(terrain.longitudes) > 0).all()
    assert terrain.sample(45, 110) is not None
    assert terrain.sample(45, 110) < 0  # Northern lowlands, below the Mars areoid.
    assert np.isfinite(terrain.slope_degrees()).all()
    assert terrain.sample(0, 0) is None

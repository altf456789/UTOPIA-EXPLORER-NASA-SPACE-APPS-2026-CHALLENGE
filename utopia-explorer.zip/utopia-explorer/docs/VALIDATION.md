# Executed validation

Verified on **15 November 2026** using Python **3.12.14**, Streamlit **1.67.0**, Plotly **6.9.0**, NumPy **2.3.5**, Pillow **13.0.0** and pytest **9.2.0** in an isolated project environment with existing scientific packages available.

## Automated tests

Executed from the project root:

```bash
python -m pytest -q
```

**89 tests passed**: 49 coordinate/distance/mission tests, 33 data-handling tests and 7 Streamlit interaction tests. The run produced one deprecation warning from the environment's external anyio pytest plugin; it did not fail a test.

- Analytic Mars distances, including a quarter circumference; no Earth radius.
- Longitude wrapping and antimeridian behavior; centric/graphic latitude round trips.
- Return retracing, selected visit order and all time-budget components.
- Equality and excessive-duration thresholds; empty destinations and invalid inputs.
- Bilinear raster samples, correct north–south indexing, no extrapolation and physical grid-gradient slope units.
- Missing/corrupt source files and recorded asset-integrity failures.
- Default mission, excessive-duration warning, multiple stops, cleared destinations and example reset.
- All five map choices at both EVA and regional extents, without application exceptions.

## Source checks

Executed:

```bash
python scripts/validate_data.py
```

Result: **passed**, saved in `DATA_CHECKS.json`. The real MOLA crop contains **59,392 finite cells**, shape **232 × 256**, range **−5,023 to −4,761 m** relative to its areoid. The gridded base interpolation is **−4,929.25 m**, an orbital-grid estimate rather than a habitat ground measurement. Actual source metadata and coordinate arrays cover the demonstration area. Geological query evidence identifies **eAb**, matching the provenance record.

NASA Trek imagery downloads, PDS MOLA byte-range extraction and geological query/export scripts were executed successfully. A fresh geology acquisition reproduced the bundled point response, source-layer metadata and both geological images byte-for-byte. The full MOLA source file was not downloaded; only the validated byte range was fetched and hashed.

## Application launch and browser checks

Executed:

```bash
python -m streamlit run app.py --server.address 0.0.0.0 --server.port 8501 --server.headless true
```

- Streamlit launched and `/_stcore/health` returned **HTTP 200**, body **ok**.
- Chromium rendered the real THEMIS map and default route at **1512 × 1100**.
- **Zero application exception panels and zero JavaScript page errors** were observed.
- At **390 × 844**, the responsive layout had no horizontal document overflow. This is a bounded viewport check, not an exhaustive device-accessibility audit.
- Science and source tabs opened successfully.
- The browser downloaded `EVA-01_mission_plan.json`; it parsed successfully and contains round-trip distance **3.4491519390219305 km** and total required budget **2.6038133079258046 h**.
- With all external HTTPS requests blocked in that browser context, the bundled map rendered and the mission still exported. Package installation and source links still need a network connection.

Screenshots are in `screenshots/`; an example browser-exported mission is in `examples/`. They show the tested default scenario. Source notes and AI disclosure accompany the app.

## Remaining limits

Passing software tests does not establish the correctness of every scientific interpretation, human performance model or operational route. No terrain-safe path, local ice confirmation, current weather feed, suit-consumables model or evaluated landing site is provided. The official supplied 2026 challenge page returned HTTP 503; competition rules and eligibility remain unverified. No production deployment was performed.

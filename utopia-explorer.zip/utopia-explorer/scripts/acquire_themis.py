"""Download verified Mars Odyssey THEMIS IR mosaic crop via NASA Trek WMTS."""
from pathlib import Path
from datetime import datetime, timezone
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
import argparse,hashlib,json,math,xml.etree.ElementTree as ET,io
from PIL import Image
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,default=HERE/'assets',help='Asset output directory')
OUT=parser.parse_args().output.resolve();OUT.mkdir(parents=True,exist_ok=True)
NS={'w':'http://www.opengis.net/wmts/1.0','o':'http://www.opengis.net/ows/1.1'}
layer='THEMIS_DayIR_ControlledMosaics_100m_v2_oct2018'
base=f'https://trek.nasa.gov/tiles/Mars/EQ/{layer}/1.0.0/'
def get(url):
 with urlopen(Request(url,headers={'User-Agent':'UtopiaExplorer/1.0 educational data validation'}),timeout=45) as r:
  if r.status!=200:raise RuntimeError(f'HTTP{r.status} for{url}')
  return r.read()
def sha(b):return hashlib.sha256(b).hexdigest()
cap=get(base+'WMTSCapabilities.xml');(OUT/'themis_wmts.xml').write_bytes(cap)
r=ET.fromstring(cap);ms=r.findall('.//w:TileMatrixSet/w:TileMatrix',NS);z=max(int(m.find('o:Identifier',NS).text) for m in ms)
m=next(m for m in ms if int(m.find('o:Identifier',NS).text)==z)
tsize=int(m.find('w:TileWidth',NS).text);width=int(float(m.find('w:MatrixWidth',NS).text));dpp=360/width/tsize
bounds={'west':109.,'east':111.,'north':46.,'south':44.}
x0=math.floor((bounds['west']+180)/dpp);x1=math.ceil((bounds['east']+180)/dpp)
y0=math.floor((90-bounds['north'])/dpp);y1=math.ceil((90-bounds['south'])/dpp)
items=[(row,col) for row in range(y0//tsize,(y1-1)//tsize+1) for col in range(x0//tsize,(x1-1)//tsize+1)]
r0=min(r for r,c in items);c0=min(c for r,c in items)
full=Image.new('RGBA',((max(c for r,c in items)-c0+1)*tsize,(max(r for r,c in items)-r0+1)*tsize))
def tile(item):
 row,col=item;url=f'{base}default/default028mm/{z}/{row}/{col}.png';data=get(url);im=Image.open(io.BytesIO(data));im.load()
 if im.size!=(tsize,tsize):raise RuntimeError('Unexpected tile shape')
 return row,col,url,data,im.convert('RGBA')
tiles=[]
for row,col,url,data,im in ThreadPoolExecutor(max_workers=6).map(tile,items):
 full.paste(im,((col-c0)*tsize,(row-r0)*tsize))
 tiles.append({'row':row,'col':col,'url':url,'sha256':sha(data),'bytes':len(data)})
crop=full.crop((x0-c0*tsize,y0-r0*tsize,x1-c0*tsize,y1-r0*tsize))
crop.save(OUT/'themis_dayir.png')
md={
 'title':'Mars Odyssey THEMIS controlled daytime infrared mosaic,100m version2 October2018',
 'source':'NASA/JPL-Caltech/Arizona State University, THEMIS Science Team; distributed by NASA Mars Trek',
 'capabilities_url':base+'WMTSCapabilities.xml','source_catalog_url':'https://trek.nasa.gov/mars/TrekServices/ws/index/eq/searchItems?key=THEMIS_DayIR_ControlledMosaics_100m_v2_oct2018&start=0&rows=10&proj=eq',
 'supported_crs_as_advertised':'urn:ogc:def:crs:EPSG::104905',
 'coordinate_convention':'Planetocentric latitude, positive-east longitude, geographic/equirectangular degree grid; NASA Trek EQ service.',
 'projection':'Equirectangular geographic-degree axes. Do not interpret as Earth Web Mercator or WGS84.',
 'bounds':{'west':x0*dpp-180,'east':x1*dpp-180,'north':90-y0*dpp,'south':90-y1*dpp},
 'bounds_semantics':'Outer pixel edges; row0 north. Pixel centers west+(col+0.5)*degrees_per_pixel,north-(row+0.5)*degrees_per_pixel.',
 'image_size_px':list(crop.size),'degrees_per_pixel':dpp,'cached_wmts_level':z,
 'source_layer_nominal_resolution_m':100,'cached_angular_grid_m_at_equator':math.radians(dpp)*3396200,
 'note':'Historical controlled thermal-infrared image mosaic. Image brightness is not calibrated local temperature or a live weather report. Source resolution nominal100m; WMTSlevel9 angular grid about81m north/south; oversampling the source does not improve its spatial resolution. Small rocks, loose soil and hazards remain unresolved.',
 'tiles':tiles,'retrieved_utc_date':datetime.now(timezone.utc).date().isoformat(),'asset_sha256':sha((OUT/'themis_dayir.png').read_bytes())}
(OUT/'themis.json').write_text(json.dumps(md,indent=2)+'\n')
print(crop.size,md['bounds'],'pixels with alpha0',crop.getchannel('A').histogram()[0])

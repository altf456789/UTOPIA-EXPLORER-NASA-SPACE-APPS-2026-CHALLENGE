# Earlier research and regional scientific context

## The supplied presentation

*The Mars Project* is a **26-page PDF supplied by the user**. It identifies **Team Tokamak Bruno**, an **11-member research team**, and a hypothetical settlement mission to Utopia Planitia in 2041. Utopia Explorer uses that work as background motivation and credits the earlier group. The current Space Apps team is **Kazakh Space Nomads**; common membership and sole authorship are not assumed.

The presentation focuses on settlement systems, including proposed energy, habitat insulation, water extraction, life support and agriculture. Its useful planning question is how explorers might investigate resources and geology near a proposed base. It does not provide validated Mars coordinates, a georeferenced dataset, an EVA traverse, or a confirmed local ice survey. Internal labels such as `y55/x65` are design-model references, not latitude and longitude.

Utopia Explorer therefore does not import its numerical claims about burial depth, reactor performance, heat recovery, water yield, crop performance or future fusion technology into its data layers. The PDF is not redistributed with the application; retain the original supplied copy for the earlier group's work.

## Independent NASA evidence

NASA/JPL's **“Mars Ice Deposit Holds as Much Water as Lake Superior”**, dated **2016-11-22**, was accessed successfully on **2026-11-15**:
https://www.jpl.nasa.gov/news/mars-ice-deposit-holds-as-much-water-as-lake-superior/

The article reports SHARAD radar analysis of more than 600 passes over part of Utopia Planitia, including an assessed ice-rich deposit at **39–49° N**. The regional study interprets deposit thicknesses of **80–170 m**, **50–85% ice**, and estimated soil cover of **1–10 m**. Those numbers describe the published study, not conditions measured at any hypothetical habitat or sampling stop in this application.

Scalloped depressions and polygonal cracking helped motivate the original investigation. These are relevant scientific questions for future mapping and reconnaissance, but this project does not invent such features at its waypoint coordinates. Even a location in the published latitude band cannot be claimed to sit over the deposit without the actual footprint and supporting observations.

The paper DOI `https://doi.org/10.1002/2016GL070138` returned HTTP 403 in this environment. The accessible NASA/JPL article is the basis for the regional statements here; direct access to the paper is not claimed.

## Geological context used in the planner

The app combines orbital imagery, topography and geology as three independently meaningful evidence categories. A NASA Trek query at **45° N, 110° E** returns **eAb, Early Amazonian basin unit**, from **Tanaka et al. (2014), Geologic Map of Mars, USGS SIM 3292**, scale **1:20,000,000**:
https://pubs.usgs.gov/sim/3292/

Service:
https://trek.nasa.gov/mars/trekarcgis/rest/services/SIM3292_Global_Geology/MapServer/0

The local cached extent is uniformly inside that coarse mapped unit. The regional geology view spans **90–130° E, 35–55° N**. A map-unit query at a hypothetical location is a classification from a published regional map, not a new field measurement, observed outcrop or evidence of local ice.

The default imagery is the controlled THEMIS daytime infrared mosaic: nominal source resolution **100 m**, cached sampling approximately **81 m north–south**. Oversampling does not improve source resolution, and brightness is not calibrated local temperature. Viking color imagery provides an alternative orbital view. MOLA elevation and its derived slope share one topographic source. See [Data sources](../DATA_SOURCES.md) for complete provenance.

## Regional figure bundled with the app

**Asset:** `data/sharad_context.jpg`  
**NASA identifier:** PIA21138  
**Title:** *Location of Large Subsurface Water-Ice Deposit in Utopia Planitia, Mars*  
**Image addition date:** 2016-11-22  
**Credit:** **NASA/JPL-Caltech/Univ. of Rome/ASI/PSI**

Verified caption URL:
https://science.nasa.gov/photojournal/location-of-large-subsurface-water-ice-deposit-in-utopia-planitia-mars/

Original JPEG URL, retrieved successfully:
https://assets.science.nasa.gov/content/dam/science/psd/photojournal/pia/pia21/pia21138/PIA21138.jpg

The original image and legend are retained. Diagonal striping indicates the region of the assessed ice-rich deposit. Violet bars indicate estimated depth to its bottom. The figure is a **static regional reference**, not a georeferenced local dataset. It must not be counted as a separately sampled local ice map, used to infer waypoint ice depth, or overlaid on the EVA map without georeferencing and appropriate validation.

SHARAD was supplied by the Italian Space Agency; operations are led by Sapienza University of Rome; U.S. involvement is led by the Planetary Science Institute. NASA/JPL-Caltech manages MRO for NASA.

## General physical context

NASA's Mars Fact Sheet was accessed successfully:
https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html

It gives a **volumetric mean radius of 3,389.5 km**, equatorial radius **3,396.2 km**, and polar radius **3,376.2 km**. Utopia Explorer uses the mean radius for its disclosed spherical surface-distance approximation.

NASA Mars Facts was also accessible:
https://science.nasa.gov/mars/facts/

It supports qualitative descriptions of a thin atmosphere mainly composed of carbon dioxide, cold conditions, dust storms and the absence of a present global magnetic field. These facts are not live conditions at the hypothetical base. Global extremes and observations from another landing site must not be displayed as a local forecast.

## Challenge verification

The exact challenge URL supplied in the request returned **HTTP 503 Service Unavailable** on **2026-11-15**:
https://www.spaceappschallenge.org/2026/challenges/interplanetary-survival-guide-martian-map/

The application addresses the requirements in the user's brief. Its documents do not imply independent verification of that listing or the 2026 competition rules.

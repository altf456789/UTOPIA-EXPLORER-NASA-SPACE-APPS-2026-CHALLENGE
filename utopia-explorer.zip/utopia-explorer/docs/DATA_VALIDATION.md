# Data validation — Utopia Explorer

Verified live downloads on 2026-11-15. This document records observations about the downloaded sources, not operational safety approval.

## Defensible study area

The educational scenario uses a deliberately round hypothetical center at **45°N, 110°E**, planetocentric latitude and positive-east longitude. It is not a published landing site, an evaluated settlement site, or a known point ice deposit. NASA/JPL's 2016 account reports a SHARAD-supported buried-ice study in the broad Utopia Planitia region at 39–49°N. That regional evidence motivates an ice-related research objective but cannot establish local ice or access at the chosen center. Genuine map layers cover the center. Local destinations are synthetic planning targets until observation-supported feature identification is completed.

Source: https://www.jpl.nasa.gov/news/mars-ice-deposit-holds-as-much-water-as-lake-superior/ . Companion image: https://science.nasa.gov/photojournal/scalloped-terrain-led-to-finding-of-buried-ice-on-mars/ .

## Orbital imagery — downloaded

NASA Mars Trek serves the genuine Viking MDIM2.1 global color mosaic, derived from Viking Orbiter imaging. The checked WMTS capability is:

https://trek.nasa.gov/tiles/Mars/EQ/Mars_Viking_MDIM21_ClrMosaic_global_232m/1.0.0/WMTSCapabilities.xml

The service advertises a geographic/equirectangular matrix, top-left longitude−180°, latitude90°, width2^(z+1) and height2^z tiles, 256pixels per tile. It declares `urn:ogc:def:crs:EPSG::104905`; that is the exact service identifier, not an Earth WGS84 conversion. The local renderer uses the supplied Mars longitude/latitude degree grid without a terrestrial map base.

The cached maximum level7 has 0.0054931640625° pixels, approximately326m north/south on Mars. The source layer's `232m` name must not be presented as the actual cached pixel spacing. The saved PNG keeps source sampling with no upsampling. Its bounds are original pixel outer edges, not pixel centers; row0 is north. Exact tile URLs and SHA256 hashes appear in `../data/imagery.json`, and the actual WMTS capability is retained.

Downloaded crop: 365×366pixels, 108.995361328125–111.0003662109375°E, 43.9947509765625–46.0052490234375°N. It provides genuine regional surface context. It does not resolve individual astronaut obstacles, soil bearing strength, or safe foot placement.

## Higher-detail orbital infrared imagery — downloaded

The NASA Trek catalog also exposes `THEMIS_DayIR_ControlledMosaics_100m_v2_oct2018`, Mars Odyssey THEMIS controlled daytime infrared mosaic, version2 October2018. Its live WMTS capability was verified:

https://trek.nasa.gov/tiles/Mars/EQ/THEMIS_DayIR_ControlledMosaics_100m_v2_oct2018/1.0.0/WMTSCapabilities.xml

The source has nominal100m resolution. Cached maximum level9 samples0.001373291015625° per pixel (about81m north/south); that resampling does not improve the original source resolution. The downloaded PNG is1457×1458pixels, 108.99948120117188–111.0003662109375°E and43.998870849609375–46.001129150390625°N, with no transparent missing pixels. Exact metadata and downloaded tile hashes are in `themis.json`; original capabilities are retained. Attribution: NASA/JPL-Caltech/Arizona State University THEMIS team, distributed by NASA Mars Trek.

This thermal-infrared mosaic offers real broad surface morphology. Pixel brightness is not local calibrated temperature or present weather. It is historical orbital imagery, and many hazards relevant to EVA remain unresolved. `python scripts/acquire_themis.py --output PATH` reproduces the crop.

## Numeric topography — downloaded

NASA PDS Geosciences provides MGS MOLA MEGDR128 topography in the product `MEGT88N090HB.IMG`:

https://pds-geosciences.wustl.edu/mgs/urn-nasa-pds-mgs_mola_topography_derived/meg128/megt88n090hb.img

The `.lbl` and `.xml` at the same URL stem are downloaded unchanged. The source label establishes:

- Planetocentric, body-fixed rotating IAU2000 coordinates; east-positive longitude.
- Simple cylindrical/equirectangular projection, central longitude180°, center/standard latitude0°, reference sphere3396.0km.
- Source coverage44–88°N and90–180°E, shape5632rows×11520columns.
- Signed big-endian16-bit integer topography in **meters relative to the source areoid**, not radius or Earth sea level.
- 128pixels/degree; exact map spacing0.4630576672km/pixel north/south and at the equator, about327m east/west at45°N.
- Each bin is median topography where sampled; unsampled bins receive interpolation. Source label reports gaps up to12km between profiles. Grid spacing must not be equated to observation density or terrain hazard detection capability.

The download uses an HTTP206 contiguous row range and then extracts the target columns without changing elevations. The validated `Content-Range`, SHA256 of the downloaded byte range, and crop indices appear in `mola.json`. The complete129761280byte source was not downloaded or fully hashed; metadata explicitly says so.

The local `mola.npz` contains `latitudes` decreasing north→south, `longitudes` increasing west→east, and `elevation_m[row,column]`. Coordinate arrays contain **pixel-center** values. Crop outer edges:109–111°E,44.09375–45.90625°N, shape232×256.59,392valid finite cells; range−5023 to−4761m. A nearby center cell is45.00390625°N109.99609375°E, elevation−4928m. These are coarse raster values, not validated ground heights at a habitat.

Source data date1997–2001; original product2003; PDS4 migration version1.1 dated2026-09-15 corrects map-scale metadata. This is historical topography, not a real-time mission feed.

A numerical gradient of this raster may be displayed as **derived regional slope**, with Mars radius and cos(latitude) used in pixel distances. It remains a derivative of MOLA, not a third independent NASA observational dataset, and does not certify local traversability.

## Geology

A live NASA Trek proxy to USGS SIM3292 was found and queried at110°E45°N. The actual response identifies `eAb`, Early Amazonian basin unit, from Tanaka et al.(2014). The scale is1:20,000,000. This supports a broad regional geological context, not composition or stratigraphy measured at a synthetic waypoint. Original service/layer metadata and query responses, a local classified raster, a wider regional map, and provenance metadata are available in `../data/`. The local raster is uniformly colored because the local study area is within one broad mapped unit. Actual source endpoint: https://trek.nasa.gov/mars/trekarcgis/rest/services/SIM3292_Global_Geology/MapServer/0 . Official publication: https://pubs.usgs.gov/sim/3292/ .

## Unavailable / unimplemented data

USGS planetary mapping and Astrogeology endpoints returned HTTP403 from this environment. NASA Trek and PDS Geosciences alternate distribution endpoints succeeded, and exact downloads are cached for offline use. No local SHARAD footprint/ice-depth grid, high-resolution boulder/rock map, validated hazard polygons, local hourly weather, live radiation, dust visibility, surface trafficability or suit-resource model has been obtained. Those remain unknown. General Mars environment facts must be separately cited and not presented as current conditions at the scenario coordinates.

## Reproduction

Run `python scripts/acquire_mars_data.py --output PATH` from the project root with NumPy and Pillow installed. The `--output` argument selects the output directory (use `data` to refresh the app cache); it fetches the actual advertised maximum WMTS level, verifies tile sizes and HTTP partial responses, and writes metadata together with the source labels. The script intentionally raises if requests fail; it never substitutes simulated terrain.

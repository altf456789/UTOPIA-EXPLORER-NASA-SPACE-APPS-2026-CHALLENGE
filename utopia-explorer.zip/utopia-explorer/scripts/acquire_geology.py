"""Reproduce coarse USGS Mars geology data through the verified NASA Trek proxy.

Run from the project root: python scripts/acquire_geology.py --output data
This script fetches real source responses and rasters. It never substitutes a
synthetic map if a service fails. Raster pixels do not improve the source
geological map's 1:20,000,000 interpretation scale.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen

from PIL import Image

SERVICE = "https://trek.nasa.gov/mars/trekarcgis/rest/services/SIM3292_Global_Geology/MapServer"
LAYER = SERVICE + "/0"
CAPABILITIES = "https://trek.nasa.gov/tiles/Mars/EQ/SIM3292_Global_Geology/1.0.0/WMTSCapabilities.xml"
LOCAL_BOUNDS = {"west": 109.6, "south": 44.7, "east": 110.4, "north": 45.3}
REGION_BOUNDS = {"west": 90.0, "south": 35.0, "east": 130.0, "north": 55.0}


def fetch(url: str) -> bytes:
    request = Request(url, headers={"User-Agent": "UtopiaExplorer educational Mars data provenance/1.0"})
    with urlopen(request, timeout=45) as response:
        if response.status != 200:
            raise RuntimeError(f"Unexpected HTTP {response.status}: {url}")
        return response.read()


def fetch_json(url: str) -> tuple[bytes, dict]:
    raw = fetch(url)
    value = json.loads(raw)
    if "error" in value:
        raise RuntimeError(f"Source service error: {value['error']}")
    return raw, value


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def make_url(endpoint: str, params: dict) -> str:
    return endpoint + "?" + urlencode(params)


def proxy_image_url(href: str) -> str:
    """Trek's service reports its internal HTTP /arcgis route; use its HTTPS proxy."""
    parsed = urlsplit(href)
    if parsed.hostname != "trek.nasa.gov":
        raise RuntimeError(f"Unexpected export image host: {href}")
    if parsed.path.startswith("/arcgis/"):
        return "https://trek.nasa.gov/mars/trekarcgis/" + parsed.path[len("/arcgis/"):]
    if parsed.path.startswith("/mars/trekarcgis/"):
        return "https://trek.nasa.gov" + parsed.path
    raise RuntimeError(f"Unrecognized Trek export route: {href}")


def export_image(output: Path, stem: str, bounds: dict, size: tuple[int, int]) -> dict:
    bbox = ",".join(str(bounds[k]) for k in ("west", "south", "east", "north"))
    params = {
        "f": "pjson", "bbox": bbox, "bboxSR": "104905", "imageSR": "104905",
        "size": f"{size[0]},{size[1]}", "format": "png32", "transparent": "true",
        "layers": "show:0",
    }
    url = make_url(SERVICE + "/export", params)
    response_raw, response = fetch_json(url)
    expected_extent = {"xmin": bounds["west"], "ymin": bounds["south"],
                       "xmax": bounds["east"], "ymax": bounds["north"]}
    if any(abs(response["extent"][k] - value) > 1e-8 for k, value in expected_extent.items()):
        raise RuntimeError(f"Export extent changed: {response['extent']}")
    if (response["width"], response["height"]) != size:
        raise RuntimeError("Source export returned an unexpected size")
    image_url = proxy_image_url(response["href"])
    image_raw = fetch(image_url)
    with Image.open(io.BytesIO(image_raw)) as image:
        image.load()
        if image.size != size or image.format != "PNG":
            raise RuntimeError("Downloaded map is not the requested PNG")
    (output / f"{stem}.png").write_bytes(image_raw)
    (output / f"{stem}_export_response.json").write_bytes(response_raw)
    return {
        "file": f"{stem}.png", "sha256": sha256(image_raw), "bytes": len(image_raw),
        "image_size_px": list(size), "bounds": bounds,
        "bounds_semantics": "Outer raster edges, row zero north, columns increasing east",
        "export_request_url": url, "export_image_url": image_url,
        "export_response_file": f"{stem}_export_response.json",
        "display_export_scale": response.get("scale"),
        "scale_note": "Export display scale does not improve the source map interpretation scale of1:20,000,000.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("data"), help="Output data directory")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    source_responses = {}
    for filename, url in (
        ("geology_service_metadata.json", SERVICE + "?f=pjson"),
        ("geology_layer_metadata.json", LAYER + "?f=pjson"),
    ):
        raw, value = fetch_json(url)
        (output / filename).write_bytes(raw)
        source_responses[filename] = {"url": url, "sha256": sha256(raw)}

    point_url = make_url(LAYER + "/query", {
        "f": "pjson", "geometry": "110,45", "geometryType": "esriGeometryPoint",
        "inSR": "104905", "spatialRel": "esriSpatialRelIntersects",
        "outFields": "*", "returnGeometry": "false",
    })
    point_raw, point = fetch_json(point_url)
    (output / "geology_point_query.json").write_bytes(point_raw)
    if not point.get("features"):
        raise RuntimeError("No published geology feature returned at the scenario center")
    units = [f["attributes"] for f in point["features"]]
    # Avoid assuming a single class if the service changes or returns a boundary.
    point_summary = {"latitude": 45.0, "longitude": 110.0, "features": units}
    if len(units) == 1:
        point_summary.update({key: units[0].get(key) for key in ("Unit", "UnitDesc", "FID", "OBJECTID")})

    envelope = {"xmin": LOCAL_BOUNDS["west"], "ymin": LOCAL_BOUNDS["south"],
                "xmax": LOCAL_BOUNDS["east"], "ymax": LOCAL_BOUNDS["north"],
                "spatialReference": {"wkid": 104905}}
    local_query_url = make_url(LAYER + "/query", {
        "f": "pjson", "geometry": json.dumps(envelope, separators=(",", ":")),
        "geometryType": "esriGeometryEnvelope", "inSR": "104905",
        "spatialRel": "esriSpatialRelIntersects", "outFields": "*", "returnGeometry": "false",
    })
    local_raw, local = fetch_json(local_query_url)
    (output / "geology_local_query.json").write_bytes(local_raw)
    if not local.get("features"):
        raise RuntimeError("No geology feature returned for the local map bounds")
    local_units = sorted({f["attributes"]["Unit"] for f in local["features"]})

    capability_raw = fetch(CAPABILITIES)
    if b"SIM3292_Global_Geology" not in capability_raw:
        raise RuntimeError("Unexpected WMTS capability document")
    (output / "geology_wmts.xml").write_bytes(capability_raw)
    local_image = export_image(output, "geology_local", LOCAL_BOUNDS, (800, 600))
    region_image = export_image(output, "geology_region", REGION_BOUNDS, (1000, 500))

    metadata = {
        "name": "Geologic Map of Mars (SIM3292)",
        "authors": "Tanaka, K.L., Skinner, J.A. Jr., Dohm, J.M., Irwin, R.P. III, Kolb, E.J., Fortezzo, C.M., Platz, T., Michael, G.G., and Hare, T.M. (2014)",
        "source_url": "https://pubs.usgs.gov/sim/3292/", "doi": "10.3133/sim3292",
        "service_url": LAYER, "source_scale": "1:20,000,000",
        "crs": "ESRI:104905 (GCS_Mars_2000), planetocentric latitude/positive-east longitude in degrees",
        "local_bounds": LOCAL_BOUNDS, "region_bounds": REGION_BOUNDS,
        "local_point_query": point_summary,
        "local_point_query_url": point_url,
        "local_point_query_file": "geology_point_query.json",
        "local_point_query_sha256": sha256(point_raw),
        "source_layer_metadata_file": "geology_layer_metadata.json",
        "source_service_metadata_file": "geology_service_metadata.json",
        "source_responses": source_responses,
        "local_bounds_query_file": "geology_local_query.json",
        "local_bounds_query_url": local_query_url,
        "local_bounds_query_sha256": sha256(local_raw),
        "local_bounds_intersecting_units": local_units,
        "raster_file": "geology_local.png", "region_raster_file": "geology_region.png",
        "imagery": {"local": local_image, "region": region_image},
        "wmts_capabilities_url": CAPABILITIES, "wmts_capabilities_file": "geology_wmts.xml",
        "wmts_capabilities_sha256": sha256(capability_raw),
        "verified_utc": datetime.now(timezone.utc).date().isoformat(),
        "limitations": [
            "Global-scale geological interpretation at1:20,000,000; not a local terrain or rock-composition survey.",
            "Export raster pixel size and display scale do not increase geological precision or establish local hazards.",
            "Mapped basin units do not establish presence, depth, accessibility or purity of local subsurface water ice.",
            "Local raster can be uniform when the entire extent is inside one coarse mapped unit.",
            "Hypothetical habitat and waypoints are scenario coordinates, not documented geological observations.",
        ],
    }
    (output / "geology.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(f"Downloaded geology to {output}")
    print("Scenario center:", point_summary)
    print("Local bounds intersecting published units:", ", ".join(local_units))
    print("Source geological map scale:1:20,000,000; raster pixels do not improve it.")


if __name__ == "__main__":
    main()

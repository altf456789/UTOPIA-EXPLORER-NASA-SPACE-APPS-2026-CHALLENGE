"""Reproduce compact scientific-data checks on the exact bundled products."""
from pathlib import Path
import hashlib
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from utopia.data import load_bundle  # noqa: E402


def main():
    bundle = load_bundle(ROOT / "data")
    if bundle.errors:
        raise SystemExit("\n".join(bundle.errors))
    if bundle.terrain is None or bundle.imagery is None or bundle.themis is None or bundle.geology is None:
        raise SystemExit("A required bundled source is missing")
    terrain = bundle.terrain
    z = terrain.elevation_m
    point = json.loads((ROOT / "data/geology_point_query.json").read_text())
    attributes = point["features"][0]["attributes"]
    if attributes["Unit"] != bundle.geology["local_point_query"]["Unit"]:
        raise SystemExit("Geology classification disagrees with original query")
    if list(z.shape) != terrain.metadata["shape"]:
        raise SystemExit("MOLA dimensions disagree with metadata")
    if not np.isfinite(z).all():
        raise SystemExit("Bundled MOLA crop has missing cells")
    if terrain.sample(45, 110) is None:
        raise SystemExit("MOLA does not cover scenario center")
    hashes = dict(bundle.geology.get("imagery_sha256", {}))
    for entry in bundle.geology.get("imagery", {}).values():
        hashes[entry["file"]] = entry["sha256"]
    for filename, expected in hashes.items():
        if hashlib.sha256((ROOT / "data" / filename).read_bytes()).hexdigest() != expected:
            raise SystemExit(f"Geological map integrity failed: {filename}")
    report = {
        "status": "passed",
        "scope": "Bundled coordinate/coverage, shape, finite-value and recorded-integrity checks; not scientific ground truth verification",
        "mola": {"shape": list(z.shape), "valid_cells": int(np.isfinite(z).sum()),
                 "latitude_order": "north to south", "longitude_order": "positive east, increasing",
                 "units": terrain.metadata["units"], "min_m": float(z.min()), "max_m": float(z.max()),
                 "scenario_bilinear_m": terrain.sample(45, 110), "bounds": terrain.metadata["bounds"]},
        "imagery": {"viking_size": list(bundle.imagery.size), "themis_size": list(bundle.themis.size)},
        "geology_original_query": attributes,
        "interpretation_limits": ["No confirmed local ice", "No verified safe route", "Source interpolation is not new measurement", "No local environment feed"],
    }
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()

# Utopia Explorer — Mars EVA Mission Planner

**Kazakh Space Nomads · NASA Space Apps Challenge 2026 prototype**

Plan a hypothetical scientific EVA in Utopia Planitia using genuine NASA/USGS orbital data. Select science stops, compare imagery/topography/geology, and budget the complete return to a hypothetical habitat. The app runs locally in Python and Streamlit; no API keys or account are needed.

## Run in five minutes

Use Python **3.11 or later**. Python 3.12 was tested.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

On Windows PowerShell, replace the activation command with `.venv\Scripts\Activate.ps1`. Open the local URL Streamlit prints, normally **http://localhost:8501**. Run from this project directory so `.streamlit/config.toml` supplies the dark theme.

The small genuine imagery, terrain and geological map crops are bundled in `data/`. Once dependencies are installed, the core planner runs **without network access**. Source links and optional data-refresh scripts need the internet. The app does not fetch live weather or environmental measurements.

After refreshing cached datasets with a script, restart Streamlit to reload its data cache.

## What works

- Interactive Mars-coordinate Plotly map: pan, zoom, hover, toggle legend traces and change extent.
- Select one or more hypothetical destinations; selection order sets outbound visit order.
- Return geometry retraces every outbound leg in reverse order, with both journeys counted.
- Mars spherical surface distance, configurable walking speed and travel-time allowance.
- Per-stop science time, contingency reserve, EVA duration limit and budget warnings.
- Five views: THEMIS daytime IR, Viking color mosaic, MOLA elevation, derived regional slope and USGS geology.
- MOLA grid samples and outbound elevation profile; environmental information with missing local conditions explicitly identified.
- Export a JSON mission record with inputs, legs, calculations, source metadata and limitations.
- A one-button **Load EVA-01 example** reset.

The habitat and every waypoint are illustrative coordinates, **not discovered features or evaluated landing sites**. A route is conceptual. A green duration message is not a safety clearance. See [scientific limitations](docs/SCIENTIFIC_LIMITATIONS.md).

## EVA-01 demonstration

Click **Load EVA-01 example**. The origin is hypothetical Utopia Base at **45.000°N, 110.000°E**, and the default destination is **S01 · Ice-context survey**, **45.020°N, 110.030°E**. Published regional SHARAD evidence motivates reconnaissance; ice beneath either marker is unconfirmed.

| Item | Default result / input |
| --- | --- |
| Outbound distance | 1.7246 km |
| Return distance | 1.7246 km, same path reversed |
| Total spherical distance | 3.4492 km |
| Walking speed | 3 km/h |
| Travel-time allowance | 1.25 × |
| Travel estimate, both journeys | 1.4371 h |
| Science time | 25 min |
| Contingency reserve | 45 min |
| Required EVA budget | 2.6038 h |
| Maximum EVA duration | 6 h |
| Remaining budget | 3.3962 h |

Reduce **Maximum EVA duration** to **1 h** to demonstrate an excessive-duration warning. Add **S04** to demonstrate how another destination changes both distance and time. Clear all destinations to see the empty-mission state. The JSON export preserves full numerical precision; on-screen summaries are rounded.

## Scientific model

Coordinates are Mars **planetocentric latitude / positive-east longitude**, degrees. The map uses Mars raster degree coordinates directly with a locally latitude-corrected aspect ratio, without Earth tiles or Earth-distance libraries. Spherical Haversine distances use the NASA mean Mars radius **3,389.5 km**.

```text
round-trip distance = sum(outbound great-circle legs) + sum(reverse legs)
travel hours = round-trip km × allowance / speed in km/h
required hours = travel hours + science per stop + contingency reserve
remaining hours = maximum duration − required hours
```

The allowance changes estimated time, not geometry or displayed surface distance. It is a scenario assumption. Elevation is not integrated into a 3D path length. All times use ordinary 60-minute hours. Exact equality to the time limit produces an at-limit warning.

Three independent **data categories** are combined: orbital imagery, topography and published geological mapping. Slope is a derivative of MOLA, not an independent observation. The SHARAD figure is regional research context, not a local ice overlay. THEMIS mosaic brightness is not calibrated current temperature.

## Verification

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

Tests cover coordinate conversion, longitude wrapping, analytic Mars distances, travel budgets, exact return retracing, duration boundaries, invalid inputs, missing/corrupt observations, raster sampling and regional slope units. App tests exercise the destination selector, budget warning, demo reset and map views. See [the executed verification record](docs/VALIDATION.md) for results and browser checks.

## Project structure

```text
app.py                     Streamlit interface and illustrative mission
utopia/core.py             Coordinates, Mars distances and EVA budget
utopia/data.py             Integrity-aware local data loading and sampling
utopia/map_view.py         Plotly Mars map and MOLA profile
data/                      Real cached crops, source labels and metadata
scripts/                   Reproducible source downloads and data checks
tests/                     Scientific, missing-data and app integration tests
docs/                      Scientific limits, credit, AI disclosure and demo
```

## Sources, credit and submission

- [Data sources and attribution](DATA_SOURCES.md)
- [Source-access validation](docs/DATA_VALIDATION.md)
- [Scientific assumptions and limitations](docs/SCIENTIFIC_LIMITATIONS.md)
- [Earlier collaborative research credit](docs/RESEARCH_CONTEXT.md)
- [AI assistance disclosure](docs/AI_DISCLOSURE.md)
- [Concise project description](docs/PROJECT_DESCRIPTION.md)
- [Suggested two-minute demonstration](docs/DEMO_SCRIPT.md)

The earlier supplied *The Mars Project* presentation credits **Team Tokamak Bruno**. It is used as background; unverified habitat/engineering assumptions were not converted into observations or claimed as one individual's original work. The current project team is **Kazakh Space Nomads**.

The user-supplied [2026 challenge page](https://www.spaceappschallenge.org/2026/challenges/interplanetary-survival-guide-martian-map/) returned HTTP 503 during source verification. The project follows the challenge wording in the brief; the team should check the official page and submission rules when available. NASA/USGS attribution does not imply endorsement or operational certification. This package is a runnable local prototype; no production hosting was deployed.
